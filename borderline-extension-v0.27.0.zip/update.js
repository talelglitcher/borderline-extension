// Shared by the background script and the popup.
//
// Update check: looks at the latest release of the extension's GitHub
// repository. When its version is newer than the installed one, the popup
// shows an UPDATE button (and the toolbar icon gets a small badge).
//
// Chrome can't update a folder loaded with "Load unpacked" by itself, so the
// popup downloads the new zip; the user unzips it over the old folder and
// clicks RELOAD. Settings are kept (they're stored by Chrome, not in the folder).

const BORDERLINE_UPDATE = (() => {
  // GitHub repository the releases are published on: "user/repository"
  const REPO = "talelglitcher/borderline-extension";

  const CHECK_EVERY_MS = 60 * 60 * 1000; // at most once an hour (GitHub limits requests)
  const STORE_KEY = "updateInfo";

  const current = () => chrome.runtime.getManifest().version;

  // "0.27.0" vs "0.26.2" -> 1 / 0 / -1
  function compare(a, b) {
    const pa = String(a).replace(/^v/i, "").split(".").map((n) => parseInt(n, 10) || 0);
    const pb = String(b).replace(/^v/i, "").split(".").map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const d = (pa[i] || 0) - (pb[i] || 0);
      if (d) return d > 0 ? 1 : -1;
    }
    return 0;
  }

  function withStatus(info) {
    if (!info) return null;
    return { ...info, current: current(), available: compare(info.latest, current()) > 0 };
  }

  // Returns { latest, url, page, notes, current, available } or null
  async function check(force = false) {
    if (!REPO) return null;
    const stored = (await chrome.storage.local.get(STORE_KEY))[STORE_KEY];
    if (!force && stored && Date.now() - stored.checkedAt < CHECK_EVERY_MS) return withStatus(stored);

    try {
      const res = await fetch(`https://api.github.com/repos/${REPO}/releases/latest`, {
        headers: { Accept: "application/vnd.github+json" },
      });
      if (!res.ok) throw new Error(`GitHub answered ${res.status}`);
      const release = await res.json();
      const zip = (release.assets || []).find((a) => /\.zip$/i.test(a.name));
      const info = {
        checkedAt: Date.now(),
        latest: String(release.tag_name || "").replace(/^v/i, ""),
        url: zip?.browser_download_url || release.html_url,
        page: release.html_url,
        notes: String(release.body || "").slice(0, 500),
      };
      await chrome.storage.local.set({ [STORE_KEY]: info });
      return withStatus(info);
    } catch {
      return withStatus(stored); // offline or rate-limited: keep what we knew
    }
  }

  // Small badge on the toolbar icon while an update is waiting
  async function updateBadge(info) {
    try {
      await chrome.action.setBadgeBackgroundColor({ color: "#F93C3C" });
      await chrome.action.setBadgeText({ text: info?.available ? "NEW" : "" });
    } catch {}
  }

  return { REPO, check, updateBadge, compare };
})();
