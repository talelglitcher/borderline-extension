// Extension "isolated" world.
//
// Victory celebration: a short full-screen 3D scene in the Borderline style,
// played over the end screen when you win (triggered by the "ofc-victory"
// event from win-detect.js).
//
// Timeline (~5.6 s, the length of the victory sound):
//   0.0 s  cinematic bars slide in, warp-speed pixel streaks rush at the camera
//   0.3 s  white flash, double shockwave, the 3D stage flies in:
//          synthwave radar floor + radar sweep, gyroscope of red rings,
//          the spinning gold coin with orbiting pixel satellites, god rays
//   0.9 s  "VICTORY" letters flip in one by one in extruded 3D,
//          glitch + screen shake on impact, then a light shine sweeps across
//   1.0 s+ three bursts of 3D pixel confetti + sparkles, "TERRITORY SECURED"
//          types in under the title
//   5.6 s  fade out to the end screen. Click anywhere to skip.

(() => {
  const DURATION_MS = 5600;
  const FADE_MS = 700;
  const APPLE_URL = chrome.runtime.getURL("icons/gold-coin.webp"); // the reward at the center (animated pixel coin)
  const COLORS = ["#F93C3C", "#E66161", "#C32E2E", "#FFFFFF", "#FCD34D", "#4ADE80"];
  const TITLE = "VICTORY";
  const SUBTITLE = "TERRITORY SECURED";
  const DEPTH_LAYERS = 9; // thickness of the 3D letters
  const SATELLITES = 8; // pixels orbiting the apple

  const CSS = `
    #ofc-victory {
      position: fixed; inset: 0; margin: 0; padding: 0; border: 0;
      width: 100vw; height: 100vh; max-width: none; max-height: none;
      background: radial-gradient(ellipse at 50% 40%, rgba(90, 14, 14, .55), rgba(18, 7, 7, .95) 72%);
      overflow: hidden; cursor: pointer; z-index: 2147483647; color: #fff;
      animation: ofc-v-in .3s ease-out both;
    }
    #ofc-victory.ofc-v-out { animation: ofc-v-out ${FADE_MS}ms ease-in both; }
    #ofc-victory canvas { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; }

    /* Whole scene: perspective + screen shake when the title lands */
    #ofc-victory .ofc-v-world {
      position: absolute; inset: 0; perspective: 1000px; perspective-origin: 50% 40%;
      animation: ofc-v-shake .45s linear 1.55s both;
    }

    /* Synthwave radar floor */
    #ofc-victory .ofc-v-floor {
      position: absolute; left: -50%; right: -50%; top: 55%; height: 120vh;
      transform-origin: 50% 0; transform: rotateX(78deg);
      background:
        linear-gradient(rgba(249, 60, 60, .55) 2px, transparent 2px) 0 0 / 100% 60px,
        linear-gradient(90deg, rgba(249, 60, 60, .55) 2px, transparent 2px) 0 0 / 60px 100%;
      mask-image: linear-gradient(to bottom, transparent 0%, #000 18%, #000 60%, transparent 100%);
      animation: ofc-v-floor-in 1s cubic-bezier(.2, .8, .2, 1) .2s both, ofc-v-floor-move .6s linear infinite;
    }
    #ofc-victory .ofc-v-horizon {
      position: absolute; left: 0; right: 0; top: calc(55% - 2px); height: 3px;
      background: linear-gradient(90deg, transparent, #F93C3C 20%, #fff 50%, #F93C3C 80%, transparent);
      box-shadow: 0 0 24px 6px rgba(249, 60, 60, .6);
      animation: ofc-v-horizon .8s ease-out .25s both;
    }

    /* God rays + radar sweep behind the apple */
    #ofc-victory .ofc-v-rays {
      position: absolute; left: 50%; top: 40%; width: 1600px; height: 1600px; margin: -800px;
      background: repeating-conic-gradient(rgba(249, 60, 60, .16) 0deg 7deg, transparent 7deg 20deg);
      mask-image: radial-gradient(circle, #000 10%, transparent 58%);
      animation: ofc-v-spin 20s linear infinite, ofc-v-fadein .8s ease-out .3s both;
    }
    #ofc-victory .ofc-v-sweep {
      position: absolute; left: 50%; top: 40%; width: 900px; height: 900px; margin: -450px; border-radius: 50%;
      background: conic-gradient(from 0deg, rgba(249, 60, 60, .45), rgba(249, 60, 60, 0) 60deg, transparent 360deg);
      mask-image: radial-gradient(circle, #000 35%, transparent 70%);
      animation: ofc-v-spin 1.6s linear infinite, ofc-v-fadein .6s ease-out .4s both;
    }

    /* Flash + shockwaves */
    #ofc-victory .ofc-v-flash {
      position: absolute; inset: 0; background: #fff; pointer-events: none;
      animation: ofc-v-flash .55s ease-out .28s both;
    }
    #ofc-victory .ofc-v-wave {
      position: absolute; left: 50%; top: 40%; width: 40px; height: 40px; margin: -20px;
      border: 4px solid #F93C3C; border-radius: 50%; opacity: 0;
      animation: ofc-v-wave 1.2s cubic-bezier(.1, .7, .2, 1) .3s both;
    }
    #ofc-victory .ofc-v-wave.w2 { animation-delay: .5s; border-color: #FCD34D; }
    #ofc-victory .ofc-v-wave.w3 { animation-delay: 1.55s; border-color: #fff; border-width: 2px; }

    /* 3D stage: gyroscope rings + golden apple + satellites */
    #ofc-victory .ofc-v-stage {
      position: absolute; left: 50%; top: 40%; width: 0; height: 0;
      transform-style: preserve-3d;
      animation: ofc-v-stage 1.3s cubic-bezier(.15, .9, .2, 1.15) .3s both, ofc-v-sway 4s ease-in-out 1.6s infinite alternate;
    }
    #ofc-victory .ofc-v-ring {
      position: absolute; border-radius: 50%; transform-style: preserve-3d;
      border: 4px solid #F93C3C;
      box-shadow: 0 0 22px rgba(249, 60, 60, .7), inset 0 0 22px rgba(249, 60, 60, .4);
    }
    #ofc-victory .r1 { width: 320px; height: 320px; margin: -160px; animation: ofc-v-r1 3.2s linear infinite; }
    #ofc-victory .r2 { width: 256px; height: 256px; margin: -128px; border-color: #E66161; border-style: dashed; animation: ofc-v-r2 2.4s linear infinite; }
    #ofc-victory .r3 { width: 196px; height: 196px; margin: -98px; border-color: #FCD34D; border-width: 2px; box-shadow: 0 0 18px rgba(252, 211, 77, .6); animation: ofc-v-r3 1.9s linear infinite; }
    #ofc-victory .ofc-v-orbit { position: absolute; transform-style: preserve-3d; animation: ofc-v-orbit 2.8s linear infinite; }
    #ofc-victory .ofc-v-sat {
      position: absolute; width: 10px; height: 10px; margin: -5px;
      background: #FCD34D; box-shadow: 0 0 10px #FCD34D, 0 0 2px #fff;
    }
    #ofc-victory .ofc-v-sat:nth-child(even) { background: #F93C3C; box-shadow: 0 0 10px #F93C3C; }
    #ofc-victory .ofc-v-apple {
      position: absolute; width: 124px; height: 124px; margin: -62px;
      image-rendering: pixelated;
      filter: drop-shadow(0 0 26px rgba(252, 211, 77, .95)) drop-shadow(0 0 6px #fff);
      animation: ofc-v-apple 2.2s ease-in-out infinite, ofc-v-pop 1s cubic-bezier(.2, 1.7, .4, 1) .45s both;
    }
    #ofc-victory .ofc-v-glow {
      position: absolute; width: 420px; height: 420px; margin: -210px; border-radius: 50%;
      background: radial-gradient(circle, rgba(252, 211, 77, .45), rgba(249, 60, 60, .16) 42%, transparent 70%);
      animation: ofc-v-pulse 1s ease-in-out infinite alternate;
    }

    /* Extruded 3D letters, flipping in one by one */
    #ofc-victory .ofc-v-title {
      position: absolute; left: 50%; top: 73%; display: flex; gap: 6px;
      transform: translate(-50%, -50%); transform-style: preserve-3d;
      animation: ofc-v-tilt 3s ease-in-out 1.7s infinite alternate;
    }
    #ofc-victory .ofc-v-letter {
      position: relative; transform-style: preserve-3d;
      font: 60px/1 "OFC Pixel", monospace;
      animation: ofc-v-letter .7s cubic-bezier(.2, 1.5, .35, 1) both;
    }
    #ofc-victory .ofc-v-letter span { position: absolute; left: 0; top: 0; }
    #ofc-victory .ofc-v-letter .front {
      position: relative;
      background: linear-gradient(110deg, #ffd0d0 0%, #F93C3C 35%, #fff 48%, #F93C3C 61%, #C32E2E 100%) 0 0 / 300% 100%;
      -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
      filter: drop-shadow(0 0 12px rgba(249, 60, 60, .75));
      animation: ofc-v-shine 1.4s ease-in-out 1.9s both, ofc-v-glitch .35s steps(2) 1.55s both;
    }
    #ofc-victory .ofc-v-sub {
      position: absolute; left: 50%; top: calc(73% + 58px); transform: translateX(-50%);
      font: 13px/1 "OFC Pixel", monospace; letter-spacing: .35em; color: #E66161; white-space: nowrap;
      text-shadow: 0 0 10px rgba(249, 60, 60, .6);
    }
    #ofc-victory .ofc-v-sub .caret { animation: ofc-v-blink .5s steps(1) infinite; }

    /* Cinematic bars */
    #ofc-victory .ofc-v-bar {
      position: absolute; left: 0; right: 0; height: 9vh; background: #070202; z-index: 3;
      display: flex; align-items: center; justify-content: center;
      font: 9px/1 "OFC Pixel", monospace; letter-spacing: .4em; color: rgba(230, 97, 97, .75);
    }
    #ofc-victory .ofc-v-bar.top { top: 0; border-bottom: 2px solid #F93C3C; animation: ofc-v-bar-top .5s cubic-bezier(.2, .8, .2, 1) both; }
    #ofc-victory .ofc-v-bar.bottom { bottom: 0; border-top: 2px solid #F93C3C; animation: ofc-v-bar-bottom .5s cubic-bezier(.2, .8, .2, 1) both; }

    @keyframes ofc-v-in { from { opacity: 0; } to { opacity: 1; } }
    @keyframes ofc-v-out { to { opacity: 0; transform: scale(1.06); filter: blur(6px); } }
    @keyframes ofc-v-fadein { from { opacity: 0; } to { opacity: 1; } }
    @keyframes ofc-v-flash { from { opacity: .9; } to { opacity: 0; } }
    @keyframes ofc-v-wave { 0% { transform: scale(.2); opacity: 1; } 100% { transform: scale(32); opacity: 0; } }
    @keyframes ofc-v-shake {
      0%, 100% { transform: none; }
      15% { transform: translate(-9px, 5px) rotate(-.6deg); }
      30% { transform: translate(8px, -6px) rotate(.5deg); }
      45% { transform: translate(-6px, -3px); }
      60% { transform: translate(5px, 4px); }
      80% { transform: translate(-2px, 1px); }
    }
    @keyframes ofc-v-floor-in { from { opacity: 0; transform: rotateX(78deg) translateY(40%); } to { opacity: 1; transform: rotateX(78deg); } }
    @keyframes ofc-v-floor-move { from { background-position: 0 0, 0 0; } to { background-position: 0 60px, 0 0; } }
    @keyframes ofc-v-horizon { from { transform: scaleX(0); } to { transform: scaleX(1); } }
    @keyframes ofc-v-stage { from { transform: translateZ(-1400px) rotateX(80deg) rotateZ(-90deg); opacity: 0; } to { transform: translateZ(0) rotateX(12deg) rotateZ(0); opacity: 1; } }
    @keyframes ofc-v-sway { from { transform: rotateX(12deg) rotateY(-16deg); } to { transform: rotateX(4deg) rotateY(16deg); } }
    @keyframes ofc-v-r1 { from { transform: rotateX(72deg) rotateZ(0); } to { transform: rotateX(72deg) rotateZ(360deg); } }
    @keyframes ofc-v-r2 { from { transform: rotateY(66deg) rotateZ(0); } to { transform: rotateY(66deg) rotateZ(-360deg); } }
    @keyframes ofc-v-r3 { from { transform: rotateX(-48deg) rotateY(42deg) rotateZ(0); } to { transform: rotateX(-48deg) rotateY(42deg) rotateZ(360deg); } }
    @keyframes ofc-v-orbit { from { transform: rotateX(-20deg) rotateY(0); } to { transform: rotateX(-20deg) rotateY(360deg); } }
    /* The coin GIF spins on its own: just float it gently in 3D */
    @keyframes ofc-v-apple { 0%, 100% { transform: translateZ(30px) translateY(-6px); } 50% { transform: translateZ(30px) translateY(6px); } }
    @keyframes ofc-v-pop { from { scale: 0; } to { scale: 1; } }
    @keyframes ofc-v-pulse { from { transform: scale(.88); opacity: .7; } to { transform: scale(1.12); opacity: 1; } }
    @keyframes ofc-v-spin { to { transform: rotate(360deg); } }
    @keyframes ofc-v-letter {
      from { transform: translateY(-120px) translateZ(500px) rotateX(-110deg); opacity: 0; }
      to { transform: none; opacity: 1; }
    }
    @keyframes ofc-v-tilt { from { transform: translate(-50%, -50%) rotateX(18deg) rotateY(-14deg); } to { transform: translate(-50%, -50%) rotateX(8deg) rotateY(14deg); } }
    @keyframes ofc-v-shine { from { background-position: 100% 0; } to { background-position: -50% 0; } }
    @keyframes ofc-v-glitch {
      0% { transform: translate(-4px, 0); filter: drop-shadow(-4px 0 #00e5ff) drop-shadow(4px 0 #F93C3C); }
      100% { transform: none; filter: drop-shadow(0 0 12px rgba(249, 60, 60, .75)); }
    }
    @keyframes ofc-v-blink { 50% { opacity: 0; } }
    @keyframes ofc-v-bar-top { from { transform: translateY(-100%); } to { transform: none; } }
    @keyframes ofc-v-bar-bottom { from { transform: translateY(100%); } to { transform: none; } }

    @media (prefers-reduced-motion: reduce) {
      #ofc-victory *, #ofc-victory { animation-duration: .01ms !important; animation-iteration-count: 1 !important; animation-delay: 0s !important; }
    }
  `;

  function ensureStyle() {
    if (document.getElementById("ofc-victory-style")) return;
    const style = document.createElement("style");
    style.id = "ofc-victory-style";
    style.textContent = CSS;
    (document.head || document.documentElement).append(style);
  }

  // ---------- Canvas: warp streaks, 3D pixel confetti, sparkles ----------
  function startCanvas(canvas) {
    const ctx = canvas.getContext("2d");
    const dpr = window.devicePixelRatio || 1;
    const resize = () => {
      canvas.width = innerWidth * dpr;
      canvas.height = innerHeight * dpr;
    };
    resize();

    const FOCAL = 700;
    const t0 = performance.now();

    // Warp-speed streaks rushing at the camera (first ~0.9 s)
    const stars = Array.from({ length: 260 }, () => ({
      x: (Math.random() - 0.5) * 1600,
      y: (Math.random() - 0.5) * 1000,
      z: 400 + Math.random() * 1600,
      color: Math.random() < 0.7 ? "#F93C3C" : "#FFFFFF",
    }));

    const particles = [];
    function burst(count, power, kind = "square") {
      for (let i = 0; i < count; i++) {
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.acos(2 * Math.random() - 1);
        const speed = power * (0.45 + Math.random() * 0.75);
        particles.push({
          x: 0, y: 0, z: 0,
          vx: Math.sin(phi) * Math.cos(theta) * speed,
          vy: Math.sin(phi) * Math.sin(theta) * speed - power * 0.35,
          vz: Math.cos(phi) * speed,
          size: kind === "spark" ? 3 + Math.random() * 3 : 6 + Math.random() * 9,
          spin: Math.random() * Math.PI * 2,
          spinSpeed: (Math.random() - 0.5) * 0.45,
          color: kind === "spark" ? (Math.random() < 0.5 ? "#FCD34D" : "#FFFFFF") : COLORS[(Math.random() * COLORS.length) | 0],
          life: 1,
          kind,
        });
      }
    }
    const timers = [
      setTimeout(() => { burst(170, 15); burst(60, 20, "spark"); }, 350),
      setTimeout(() => { burst(130, 12); burst(50, 16, "spark"); }, 1550),
      setTimeout(() => { burst(100, 10); burst(40, 14, "spark"); }, 3000),
    ];

    let raf = 0;
    function step(now) {
      const t = now - t0;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const cx = (innerWidth / 2) * dpr;
      const cy = innerHeight * 0.4 * dpr;

      // Warp streaks (fade out after 0.9 s)
      if (t < 1100) {
        const fade = t < 800 ? 1 : 1 - (t - 800) / 300;
        ctx.lineCap = "square";
        for (const s of stars) {
          const prevZ = s.z;
          s.z -= 38;
          if (s.z < 20) {
            s.z = 1600 + Math.random() * 400;
            continue;
          }
          const k1 = FOCAL / prevZ;
          const k2 = FOCAL / s.z;
          ctx.globalAlpha = fade * Math.min(1, 700 / s.z);
          ctx.strokeStyle = s.color;
          ctx.lineWidth = Math.max(1, 3 * k2) * dpr;
          ctx.beginPath();
          ctx.moveTo(cx + s.x * k1 * dpr, cy + s.y * k1 * dpr);
          ctx.lineTo(cx + s.x * k2 * dpr, cy + s.y * k2 * dpr);
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }

      // Confetti + sparkles
      for (const p of particles) {
        p.vy += p.kind === "spark" ? 0.12 : 0.22;
        p.vx *= 0.985; p.vy *= 0.985; p.vz *= 0.985;
        p.x += p.vx; p.y += p.vy; p.z += p.vz;
        p.spin += p.spinSpeed;
        p.life -= p.kind === "spark" ? 0.009 : 0.0045;
        const depth = FOCAL + p.z;
        if (depth <= 50 || p.life <= 0) continue;
        const k = FOCAL / depth;
        const sx = cx + p.x * k * dpr;
        const sy = cy + p.y * k * dpr;
        const s = p.size * k * dpr;
        ctx.globalAlpha = Math.max(0, Math.min(1, p.life * 1.5));
        ctx.fillStyle = p.color;
        if (p.kind === "spark") {
          // 4-point pixel twinkle
          ctx.setTransform(1, 0, 0, 1, sx, sy);
          const tw = s * (0.6 + 0.4 * Math.sin(now / 60 + p.spin * 5));
          ctx.fillRect(-tw * 1.5, -tw / 4, tw * 3, tw / 2);
          ctx.fillRect(-tw / 4, -tw * 1.5, tw / 2, tw * 3);
        } else {
          ctx.setTransform(Math.cos(p.spin), Math.sin(p.spin) * 0.3, 0, 1, sx, sy); // flip in 3D
          ctx.fillRect(-s / 2, -s / 2, s, s);
        }
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(step);
    }
    raf = requestAnimationFrame(step);
    addEventListener("resize", resize);

    return () => {
      cancelAnimationFrame(raf);
      timers.forEach(clearTimeout);
      removeEventListener("resize", resize);
    };
  }

  // "TERRITORY SECURED" typed in letter by letter
  function typeSubtitle(el) {
    let i = 0;
    const caret = '<span class="caret">_</span>';
    const tick = setInterval(() => {
      i++;
      el.innerHTML = SUBTITLE.slice(0, i) + caret;
      if (i >= SUBTITLE.length) clearInterval(tick);
    }, 45);
    return () => clearInterval(tick);
  }

  // ---------- Scene ----------
  let playing = false;

  function letterHTML(ch, index) {
    const layers = [];
    for (let d = DEPTH_LAYERS; d >= 1; d--) {
      const v = Math.round(70 + (DEPTH_LAYERS - d) * 12); // darker the deeper
      layers.push(`<span style="transform: translateZ(${-d * 2}px); color: rgb(${v + 50}, ${Math.round(v / 5)}, ${Math.round(v / 5)})">${ch}</span>`);
    }
    return `<div class="ofc-v-letter" style="animation-delay: ${0.9 + index * 0.09}s">${layers.join("")}<span class="front">${ch}</span></div>`;
  }

  function play() {
    if (playing) return;
    playing = true;
    ensureStyle();

    const root = document.createElement("div");
    root.id = "ofc-victory";
    root.popover = "manual"; // top layer: above the game's end screen and menus

    const satellites = Array.from({ length: SATELLITES }, (_, i) =>
      `<div class="ofc-v-sat" style="transform: rotateY(${(360 / SATELLITES) * i}deg) translateZ(150px)"></div>`
    ).join("");

    root.innerHTML = `
      <div class="ofc-v-world">
        <div class="ofc-v-rays"></div>
        <div class="ofc-v-floor"></div>
        <div class="ofc-v-horizon"></div>
        <div class="ofc-v-sweep"></div>
        <canvas></canvas>
        <div class="ofc-v-wave"></div><div class="ofc-v-wave w2"></div><div class="ofc-v-wave w3"></div>
        <div class="ofc-v-stage">
          <div class="ofc-v-glow"></div>
          <div class="ofc-v-ring r1"></div>
          <div class="ofc-v-ring r2"></div>
          <div class="ofc-v-ring r3"></div>
          <div class="ofc-v-orbit">${satellites}</div>
          <img class="ofc-v-apple" alt="" src="${APPLE_URL}">
        </div>
        <div class="ofc-v-title">${[...TITLE].map(letterHTML).join("")}</div>
        <div class="ofc-v-sub"></div>
      </div>
      <div class="ofc-v-bar top">BORDERLINE</div>
      <div class="ofc-v-bar bottom">CLICK TO CONTINUE</div>
      <div class="ofc-v-flash"></div>
    `;
    document.documentElement.append(root);
    try {
      root.showPopover();
    } catch {}

    const stopCanvas = startCanvas(root.querySelector("canvas"));
    let stopTyping = () => {};
    const typeTimer = setTimeout(() => (stopTyping = typeSubtitle(root.querySelector(".ofc-v-sub"))), 1900);

    let ended = false;
    function finish() {
      if (ended) return;
      ended = true;
      clearTimeout(typeTimer);
      stopTyping();
      root.classList.add("ofc-v-out");
      setTimeout(() => {
        stopCanvas();
        try {
          root.hidePopover();
        } catch {}
        root.remove();
        playing = false;
      }, FADE_MS);
    }
    const timer = setTimeout(finish, DURATION_MS);
    root.addEventListener("click", () => {
      clearTimeout(timer);
      finish();
    });
  }

  window.addEventListener("ofc-victory", play);
})();
