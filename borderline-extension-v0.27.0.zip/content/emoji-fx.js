// Runs in the openfront.io page context ("MAIN" world).
//
// Emoji send animation (always on), kept sober: when you send an emoji to
// someone, it glides along a soft curve from where you clicked to the
// player's name, settles there with a thin ring, then fades out.
// Sending to everyone (emoji on yourself) sends it up toward the top center.
//
// It's drawn on a canvas right above the game's map, and every position is
// kept in map coordinates: moving or zooming the map during the animation
// carries it along, like anything else drawn on the map.
//
// The game's emoji window calls back with the chosen emoji; we wrap that
// callback (and note who the window was opened for) without changing what
// the game does.

(() => {
  const FLIGHT_MS = 650; // glide to the player
  const HOLD_MS = 700; // stays on the name
  const FADE_MS = 350; // then fades out
  const SIZE = 44; // emoji size on screen, in px
  const RING_MS = 600;

  const RED = "#F93C3C";

  let target = null; // player the emoji window was opened for, or "all"
  let lastPointer = null; // { x, y, t } of the last click / tap

  window.addEventListener(
    "pointerdown",
    (e) => (lastPointer = { x: e.clientX, y: e.clientY, t: performance.now() }),
    true
  );

  // ---------- Hooks on the game's windows ----------
  function patchEmojiTable(cls) {
    const proto = cls.prototype;
    if (proto.__ofcEmojiFx) return;
    proto.__ofcEmojiFx = true;

    const showForPlayer = proto.showForPlayer;
    if (showForPlayer) {
      proto.showForPlayer = function (bus, player) {
        if (!this.isVisible) target = player === this.game?.myPlayer?.() ? "all" : player;
        return showForPlayer.apply(this, arguments);
      };
    }

    const showTable = proto.showTable;
    proto.showTable = function (callback) {
      const table = this;
      const wrapped = function (emoji) {
        try {
          launch(emoji, target, table);
        } catch {}
        return callback.apply(this, arguments);
      };
      return showTable.call(this, typeof callback === "function" ? wrapped : callback);
    };
  }

  function patchPlayerPanel(cls) {
    const proto = cls.prototype;
    if (proto.__ofcEmojiFx || !proto.handleEmojiClick) return;
    proto.__ofcEmojiFx = true;
    const handleEmojiClick = proto.handleEmojiClick;
    // handleEmojiClick(event, myPlayer, otherPlayer): same player = everyone
    proto.handleEmojiClick = function (e, me, other) {
      target = me === other ? "all" : other;
      return handleEmojiClick.apply(this, arguments);
    };
  }

  customElements.whenDefined("emoji-table").then(() => patchEmojiTable(customElements.get("emoji-table")));
  customElements.whenDefined("player-panel").then(() => patchPlayerPanel(customElements.get("player-panel")));

  // ---------- Map <-> screen ----------
  function getTransform(table) {
    return table?.transformHandler || document.querySelector("player-info-overlay")?.transform || null;
  }
  // Same conversion the other map overlays use: screen = origin + world × scale
  function view(transform) {
    const origin = transform.worldToScreenCoordinates({ x: 0, y: 0 });
    return { ox: origin.x, oy: origin.y, s: transform.scale || 1 };
  }
  const toWorld = (v, x, y) => ({ x: (x - v.ox) / v.s, y: (y - v.oy) / v.s });
  const toScreen = (v, p) => ({ x: v.ox + p.x * v.s, y: v.oy + p.y * v.s });

  // ---------- Overlay canvas (right above the map, below the game's UI) ----------
  const overlay = document.createElement("canvas");
  overlay.id = "ofc-emoji-fx";
  overlay.style.cssText = "position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none";
  const ctx = overlay.getContext("2d");

  function placeOverlay() {
    const mapCanvas =
      document.getElementById("webgl-debug-canvas") ||
      [...document.querySelectorAll("canvas")].find((c) => !c.id.startsWith("ofc-"));
    if (!mapCanvas) return false;
    // After the map and after our other overlays (alliance timers…)
    let anchor = mapCanvas;
    while (anchor.nextElementSibling?.id?.startsWith("ofc-") && anchor.nextElementSibling !== overlay) {
      anchor = anchor.nextElementSibling;
    }
    if (overlay.previousElementSibling !== anchor) anchor.after(overlay);
    return true;
  }

  function resize() {
    const dpr = window.devicePixelRatio || 1;
    const w = Math.round(innerWidth * dpr);
    const h = Math.round(innerHeight * dpr);
    if (overlay.width !== w || overlay.height !== h) {
      overlay.width = w;
      overlay.height = h;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
  }

  // ---------- Emoji sprites ----------
  // Drawn once at high resolution, with a thin dark outline and a soft shadow
  // so it reads well over the map.
  const RES = 3; // sprite canvas resolution compared to its on-screen size
  const sprites = new Map();

  function makeSprite(emoji) {
    if (sprites.has(emoji)) return sprites.get(emoji);
    const size = Math.round(SIZE * 1.3 * RES); // room for the outline / shadow
    const c = document.createElement("canvas");
    c.width = c.height = size;
    const o = c.getContext("2d");
    o.textAlign = "center";
    o.textBaseline = "middle";
    o.font = `${SIZE * RES}px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif`;
    o.filter =
      `drop-shadow(0 0 ${RES}px rgba(18,7,7,.9)) ` + `drop-shadow(0 ${RES * 1.5}px ${RES * 2}px rgba(0,0,0,.45))`;
    o.fillText(emoji, size / 2, size / 2 + RES * 2);
    const sprite = { canvas: c, size: size / RES };
    sprites.set(emoji, sprite);
    return sprite;
  }

  // ---------- Effects ----------
  const effects = [];
  let running = false;

  function launch(emoji, player, table) {
    if (!emoji) return;
    const transform = getTransform(table);
    if (!transform?.worldToScreenCoordinates) return;
    const v = view(transform);

    // Start: the click that picked the emoji (keyboard favorites: the window's center)
    let sx, sy;
    if (lastPointer && performance.now() - lastPointer.t < 1500) {
      sx = lastPointer.x;
      sy = lastPointer.y;
    } else {
      const box = table?.querySelector?.("div.bg-zinc-900\\/95")?.getBoundingClientRect();
      sx = box?.width ? box.left + box.width / 2 : innerWidth / 2;
      sy = box?.width ? box.top + box.height / 2 : innerHeight * 0.75;
    }

    const toAll = player === "all" || !player?.nameLocation;
    effects.push({
      sprite: makeSprite(emoji),
      transform,
      start: performance.now(),
      from: toWorld(v, sx, sy),
      player: toAll ? null : player,
      // Fallback / "everyone" target: top center of the current view
      fixedEnd: toWorld(v, innerWidth / 2, innerHeight * 0.28),
    });
    if (!running) {
      running = true;
      requestAnimationFrame(frame);
    }
  }

  // Where the emoji lands, in map coordinates (follows the name if it moves)
  function endOf(fx) {
    const loc = fx.player?.isAlive?.() !== false ? fx.player?.nameLocation?.() : null;
    return loc ? { x: loc.x, y: loc.y } : fx.fixedEnd;
  }

  const easeInOut = (k) => (k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2);
  const easeOut = (k) => 1 - Math.pow(1 - k, 3);

  function drawSprite(sprite, x, y, scale, alpha) {
    const s = sprite.size * scale;
    ctx.globalAlpha = alpha;
    ctx.drawImage(sprite.canvas, x - s / 2, y - s / 2, s, s);
    ctx.globalAlpha = 1;
  }

  function drawEffect(fx, now) {
    const v = view(fx.transform);
    const t = now - fx.start;
    const a = toScreen(v, fx.from);
    const b = toScreen(v, endOf(fx));

    if (t < FLIGHT_MS) {
      // ----- Glide: a soft curve, fading in, a touch bigger in the middle -----
      const k = t / FLIGHT_MS;
      const e = easeInOut(k);
      const dist = Math.hypot(b.x - a.x, b.y - a.y);
      const lift = Math.min(60, dist * 0.15);
      const x = a.x + (b.x - a.x) * e;
      const y = a.y + (b.y - a.y) * e - Math.sin(Math.PI * e) * lift;
      const scale = 0.75 + 0.25 * e + 0.08 * Math.sin(Math.PI * e);
      drawSprite(fx.sprite, x, y, scale, Math.min(1, k * 4));
      return true;
    }

    // ----- Arrival: a thin ring, then the emoji fades out, drifting up a little -----
    const at = t - FLIGHT_MS;
    if (at >= HOLD_MS + FADE_MS) return false;

    if (at < RING_MS) {
      const k = easeOut(at / RING_MS);
      ctx.strokeStyle = RED;
      ctx.lineWidth = 2;
      ctx.globalAlpha = 0.7 * (1 - k);
      ctx.beginPath();
      ctx.arc(b.x, b.y, SIZE * 0.45 + k * SIZE * 0.6, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    const settle = 1 + 0.06 * Math.sin(Math.min(1, at / 220) * Math.PI); // small, soft "landing"
    const fade = at < HOLD_MS ? 1 : 1 - easeOut((at - HOLD_MS) / FADE_MS);
    const drift = at < HOLD_MS ? 0 : ((at - HOLD_MS) / FADE_MS) * 10;
    drawSprite(fx.sprite, b.x, b.y - drift, settle, fade);
    return true;
  }

  function frame() {
    try {
      if (!placeOverlay()) {
        effects.length = 0;
      } else {
        resize();
        ctx.clearRect(0, 0, innerWidth, innerHeight);
        const now = performance.now();
        for (let i = effects.length - 1; i >= 0; i--) {
          let alive = false;
          try {
            alive = drawEffect(effects[i], now);
          } catch {}
          if (!alive) effects.splice(i, 1);
        }
      }
    } catch {
      effects.length = 0;
    }
    if (effects.length) {
      requestAnimationFrame(frame);
    } else {
      running = false;
      ctx.clearRect(0, 0, innerWidth, innerHeight);
    }
  }
})();
