// Runs in the openfront.io page context ("MAIN" world).
//
// Port Spots module: while you hold a port (picked in the build bar, just
// before placing it), shows where on your territory a new port should earn
// the most gold per minute:
// - your whole coast is dotted from red (poor) to green (best);
// - the 3 best spots are circled, the best one in green with its estimate;
// - if the best spot is off screen, a marker at the screen edge points to it.
//
// The estimate follows the game's own trade rules (read from its code,
// November 2026):
// - gold per trade ship = 75000 / (1 + e^(-0.03 × (tiles − 300))) + 50 × tiles,
//   where "tiles" is the distance sailed; both ports get that amount;
// - a port never trades with its owner's ports, only with ports reachable on
//   the same water, and not with players under embargo;
// - destinations are picked at random, weighted by the target port's level,
//   +1 for the closest third of ports (at least 4) and +1 for allies, both
//   bonuses only for ports 300+ tiles away (straight Manhattan distance);
// - each port level rolls once a second to launch a ship, with a chance that
//   grows after each failed roll and drops when many trade ships are at sea.
// Score = ships your port sends × average gold + ships other ports would send
// to it × gold.
// Players who have no port yet count as future partners (a port on their
// coast, nearest their name): that way there is always a recommendation, even
// early in the match. Their share is shown separately from real trade.
// Distances on water are measured on a coarse grid (4×4 tiles), so the numbers
// are estimates. Pirates and warships are not taken into account.

(() => {
  const root = document.documentElement;
  const isEnabled = () => root.dataset.ofcPortSpots === "on";

  const CELL = 4; // coarse grid size, in tiles
  const SHORT_RANGE = 300; // no bonus below this distance (game's value)
  const REFRESH_MS = 5000; // recompute while the port stays in hand
  const SLICE_MS = 8; // work done per step, so the game never stutters
  const TOP = 3; // spots circled
  const MIN_SPACING = 40; // tiles between two circled spots
  const STRUCTURE_MIN_DIST = 15; // game's minimum distance between structures
  const FUTURE_WEIGHT = 0.5; // how much a future partner (no port yet) counts in the ranking
  const STRUCTURES = ["City", "Port", "Factory", "Defense Post", "SAM Launcher", "Missile Silo"];

  const GREEN = "#4ADE80";
  const AMBER = "#FCD34D";
  const SALMON = "#E66161";

  const warn = (...a) => console.warn("[Borderline · Port spots]", ...a);

  // ---------- Game's formulas ----------
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const sigmoid = (x, k, mid) => 1 / (1 + Math.exp(-k * (x - mid)));
  const tradeGold = (tiles) => 75000 / (1 + Math.exp(-0.03 * (tiles - SHORT_RANGE))) + 50 * tiles;
  const bonusPortsNb = (n) => clamp(n / 3, 4, n);
  const spawnBoost = (ports) => (ports <= 0 ? 1 : 1 + (0.5 * clamp((6 - ports) / 5, 0, 1)) / ports);
  const saturation = (ships) =>
    Math.max(1 - sigmoid(ships, Math.LN2 / 50, 330), 0.25 * (1 - sigmoid(ships, Math.LN2 / 100, 800)));

  // Trade ships launched per minute by one port
  const rateCache = new Map();
  function shipsPerMinute(level, ownerPorts, shipsAtSea) {
    const key = `${level}|${ownerPorts}|${Math.round(shipsAtSea / 10)}`;
    if (rateCache.has(key)) return rateCache.get(key);
    const boost = spawnBoost(ownerPorts);
    const base = 100 / (boost * boost) / saturation(shipsAtSea);
    // Expected number of rolls before a launch (the chance grows after each miss)
    let expected = 0;
    let survive = 1;
    for (let r = 0; r < 1000 && survive > 1e-6; r++) {
      expected += survive;
      survive *= 1 - 1 / Math.max(1, Math.floor(base / (r + 1)));
    }
    // One check per second, `level` rolls per check, at most one launch per check
    const value = Math.min(1, Math.max(1, level) / expected) * 60;
    rateCache.set(key, value);
    return value;
  }

  // ---------- Game access ----------
  function gameContext() {
    const el = document.querySelector("player-info-overlay");
    const game = el?.game;
    const transform = el?.transform;
    if (!game || !transform?.worldToScreenCoordinates || typeof game.isWater !== "function") return null;
    return { game, transform };
  }
  // Every game panel shares the same UI state object
  function uiState() {
    for (const tag of ["build-menu", "unit-display", "control-panel", "player-panel"]) {
      const s = document.querySelector(tag)?.uiState;
      if (s) return s;
    }
    return null;
  }
  const holdingPort = () => String(uiState()?.ghostStructure ?? "") === "Port";
  const levelOf = (unit) => Math.max(1, Number(unit.level?.() ?? 1) || 1);
  const yieldToGame = () => new Promise((r) => setTimeout(r, 0));
  const isBot = (p) => String(p.type?.()) === "BOT";

  const canTrade = (a, b) => {
    try {
      return !a.hasEmbargoAgainst?.(b) && !b.hasEmbargoAgainst?.(a);
    } catch {
      return true;
    }
  };
  const friendly = (a, b) => {
    try {
      return !!a.isFriendly?.(b);
    } catch {
      return false;
    }
  };

  // ---------- Coarse water grid (once per map) ----------
  let grid = null; // { game, w, h, cw, ch, water: Uint8Array, version }

  async function buildGrid(game) {
    const w = game.width();
    const h = game.height();
    const cw = Math.ceil(w / CELL);
    const ch = Math.ceil(h / CELL);
    const water = new Uint8Array(cw * ch);
    let t0 = performance.now();
    for (let y = 0; y < h; y++) {
      const row = y * w;
      const cy = ((y / CELL) | 0) * cw;
      for (let x = 0; x < w; x++) {
        if (game.isWater(row + x)) water[cy + ((x / CELL) | 0)] = 1;
      }
      if (performance.now() - t0 > SLICE_MS) {
        await yieldToGame();
        t0 = performance.now();
      }
    }
    return { game, w, h, cw, ch, water, version: game.waterVersion?.() };
  }

  // ---------- Water distance from a port (coarse BFS, cached per tile) ----------
  const fields = new Map(); // tile -> Uint16Array of distances in cells (65535 = unreachable)

  async function distanceField(tile) {
    if (fields.has(tile)) return fields.get(tile);
    const { w, cw, ch, water } = grid;
    const dist = new Uint16Array(cw * ch).fill(65535);
    const queue = new Int32Array(cw * ch);
    let head = 0;
    let tail = 0;
    const px = ((tile % w) / CELL) | 0;
    const py = (Math.floor(tile / w) / CELL) | 0;
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        const x = px + dx;
        const y = py + dy;
        if (x < 0 || y < 0 || x >= cw || y >= ch) continue;
        const c = y * cw + x;
        if (water[c] && dist[c] === 65535) {
          dist[c] = 1;
          queue[tail++] = c;
        }
      }
    }
    let t0 = performance.now();
    let steps = 0;
    while (head < tail) {
      const c = queue[head++];
      const d = dist[c] + 1;
      const x = c % cw;
      if (x > 0 && water[c - 1] && dist[c - 1] === 65535) (dist[c - 1] = d), (queue[tail++] = c - 1);
      if (x < cw - 1 && water[c + 1] && dist[c + 1] === 65535) (dist[c + 1] = d), (queue[tail++] = c + 1);
      if (c >= cw && water[c - cw] && dist[c - cw] === 65535) (dist[c - cw] = d), (queue[tail++] = c - cw);
      if (c < cw * (ch - 1) && water[c + cw] && dist[c + cw] === 65535) (dist[c + cw] = d), (queue[tail++] = c + cw);
      if (++steps % 4096 === 0 && performance.now() - t0 > SLICE_MS) {
        await yieldToGame();
        t0 = performance.now();
      }
    }
    fields.set(tile, dist);
    return dist;
  }

  // Water distance (in tiles) from a field to a coastal tile
  function waterTiles(field, tile) {
    const { w, cw, ch } = grid;
    const cx = ((tile % w) / CELL) | 0;
    const cy = (Math.floor(tile / w) / CELL) | 0;
    let best = 65535;
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        const x = cx + dx;
        const y = cy + dy;
        if (x < 0 || y < 0 || x >= cw || y >= ch) continue;
        const d = field[y * cw + x];
        if (d < best) best = d;
      }
    }
    return best === 65535 ? Infinity : best * CELL;
  }

  // ---------- One pass over the map ----------
  // - your coast: one candidate tile per coarse cell;
  // - for every other player: the coastal tile nearest their name (where a
  //   future port of theirs would likely be).
  async function scanCoasts(game, me, others) {
    const myId = me.smallID();
    const { w, h, cw } = grid;
    const seen = new Set();
    const mine = [];
    const nearest = new Map(); // smallID -> { tile, d }
    const centers = new Map();
    for (const p of others) {
      const loc = p.nameLocation?.();
      if (loc) centers.set(p.smallID(), loc);
    }
    let t0 = performance.now();
    for (let y = 0; y < h; y++) {
      const row = y * w;
      for (let x = 0; x < w; x++) {
        const t = row + x;
        const owner = game.ownerID(t);
        if (!owner) continue;
        if (owner === myId) {
          if (!game.isShore(t)) continue;
          const cell = ((y / CELL) | 0) * cw + ((x / CELL) | 0);
          if (seen.has(cell)) continue;
          seen.add(cell);
          mine.push({ tile: t, x, y });
        } else {
          const c = centers.get(owner);
          if (!c) continue;
          const d = Math.abs(x - c.x) + Math.abs(y - c.y);
          const best = nearest.get(owner);
          if (best && best.d <= d) continue;
          if (!game.isShore(t)) continue;
          nearest.set(owner, { tile: t, d });
        }
      }
      if (performance.now() - t0 > SLICE_MS) {
        await yieldToGame();
        t0 = performance.now();
      }
    }
    return { mine, futureTiles: nearest };
  }

  // ---------- Scoring ----------
  let result = null; // { cands: [{x, y, score}], spots: [...], max, at, note }
  let computing = false;

  async function compute() {
    const gc = gameContext();
    if (!gc) return;
    const { game } = gc;
    const me = game.myPlayer?.();
    if (!me?.isAlive?.()) {
      result = { cands: [], spots: [], at: performance.now(), note: "" };
      return;
    }

    if (!grid || grid.game !== game || grid.version !== game.waterVersion?.()) {
      grid = await buildGrid(game);
      fields.clear();
    }

    const myId = me.smallID();
    const ports = game.units("Port").filter((p) => p.isActive?.() !== false);
    const shipsAtSea = game.units("Trade Ship").length;
    const portsByOwner = new Map();
    for (const p of ports) {
      const id = p.owner().smallID();
      portsByOwner.set(id, (portsByOwner.get(id) || 0) + 1);
    }
    const myPorts = portsByOwner.get(myId) || 0;

    const others = game
      .players()
      .filter((p) => p.smallID() !== myId && p.isAlive?.() !== false && !isBot(p) && canTrade(me, p));
    const { mine, futureTiles } = await scanCoasts(game, me, others);
    if (!mine.length) {
      result = { cands: [], spots: [], at: performance.now(), note: "NO COAST IN YOUR TERRITORY" };
      return;
    }

    // Partners: real ports of other players, plus a "future" port for every
    // other player who has none yet
    const partners = [];
    for (const q of ports) {
      const owner = q.owner();
      if (owner.smallID() === myId || !canTrade(me, owner)) continue;
      partners.push({ tile: q.tile(), owner, level: levelOf(q), future: false });
    }
    for (const p of others) {
      if (portsByOwner.get(p.smallID())) continue;
      const f = futureTiles.get(p.smallID());
      if (f) partners.push({ tile: f.tile, owner: p, level: 1, future: true });
    }
    if (!partners.length) {
      result = { cands: [], spots: [], at: performance.now(), note: "NO TRADE PARTNER ON THE MAP" };
      return;
    }
    for (const p of partners) p.field = await distanceField(p.tile);

    // For each partner: the ports it would send to (everyone else's), sorted
    // by straight distance, and their total pick weight
    for (const q of partners) {
      const targets = partners
        .filter((o) => o !== q && o.owner.smallID() !== q.owner.smallID())
        .filter((o) => waterTiles(q.field, o.tile) !== Infinity)
        .map((o) => ({ o, d: game.manhattanDist(q.tile, o.tile) }));
      for (const p of ports) {
        if (p.owner().smallID() !== myId) continue;
        if (waterTiles(q.field, p.tile()) === Infinity) continue;
        targets.push({ o: { owner: me, level: levelOf(p) }, d: game.manhattanDist(q.tile, p.tile()) });
      }
      targets.sort((a, b) => a.d - b.d);
      q.nb = bonusPortsNb(targets.length + 1);
      q.dists = targets.map((t) => t.d);
      q.total = 0;
      targets.forEach((t, i) => {
        let r = 1;
        const short = t.d < SHORT_RANGE;
        if (!short && i < q.nb) r++;
        if (!short && friendly(q.owner, t.o.owner)) r++;
        q.total += t.o.level * r;
      });
      q.friendlyToMe = friendly(q.owner, me);
      q.rate = shipsPerMinute(q.level, Math.max(1, portsByOwner.get(q.owner.smallID()) || 0), shipsAtSea);
    }

    const myRate = shipsPerMinute(1, myPorts + 1, shipsAtSea);
    const myStructures = me.units?.(...STRUCTURES) || [];

    const cands = [];
    let t0 = performance.now();
    for (const c of mine) {
      // Too close to one of your buildings: the game won't place it there
      if (myStructures.some((u) => game.manhattanDist(u.tile(), c.tile) < STRUCTURE_MIN_DIST)) continue;

      const reach = [];
      for (const q of partners) {
        const tiles = waterTiles(q.field, c.tile);
        if (tiles === Infinity) continue;
        reach.push({ q, tiles, d: game.manhattanDist(c.tile, q.tile) });
      }
      if (!reach.length) continue;
      reach.sort((a, b) => a.d - b.d);

      // Ships your new port sends: average gold over its likely destinations
      const nb = bonusPortsNb(reach.length);
      let wSum = 0;
      let gReal = 0;
      let gFuture = 0;
      reach.forEach((p, idx) => {
        let r = 1;
        const short = p.d < SHORT_RANGE;
        if (!short && idx < nb) r++;
        if (!short && p.q.friendlyToMe) r++;
        const wgt = p.q.level * r;
        wSum += wgt;
        if (p.q.future) gFuture += wgt * tradeGold(p.tiles);
        else gReal += wgt * tradeGold(p.tiles);
      });
      let real = (myRate * gReal) / wSum;
      let future = (myRate * gFuture) / wSum;

      // Ships other ports would send to it
      for (const p of reach) {
        const q = p.q;
        let rank = 0;
        while (rank < q.dists.length && q.dists[rank] < p.d) rank++;
        let r = 1;
        const short = p.d < SHORT_RANGE;
        if (!short && rank < q.nb) r++;
        if (!short && q.friendlyToMe) r++;
        const incoming = q.rate * (r / (q.total + r)) * tradeGold(p.tiles);
        if (q.future) future += incoming;
        else real += incoming;
      }

      cands.push({ x: c.x, y: c.y, real, future, score: real + FUTURE_WEIGHT * future });
      if (performance.now() - t0 > SLICE_MS) {
        await yieldToGame();
        t0 = performance.now();
      }
    }

    if (!cands.length) {
      result = { cands: [], spots: [], at: performance.now(), note: "NO PARTNER REACHABLE BY SEA" };
      return;
    }

    // Best spots, spread out along the coast
    const sorted = [...cands].sort((a, b) => b.score - a.score);
    const spots = [];
    for (const s of sorted) {
      if (spots.every((o) => Math.abs(o.x - s.x) + Math.abs(o.y - s.y) >= MIN_SPACING)) spots.push(s);
      if (spots.length >= TOP) break;
    }
    const min = sorted[sorted.length - 1].score;
    const max = sorted[0].score;
    result = { cands, spots, min, max, at: performance.now(), note: "" };
  }

  async function refresh() {
    if (computing) return;
    computing = true;
    try {
      await compute();
    } catch (err) {
      warn("estimate failed:", err);
      result = { cands: [], spots: [], at: performance.now(), note: "PORT SPOTS: ERROR (SEE CONSOLE)" };
    }
    computing = false;
  }

  // ---------- Drawing ----------
  const overlay = document.createElement("canvas");
  overlay.id = "ofc-port-spots";
  overlay.style.cssText = "position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none";
  const ctx = overlay.getContext("2d");

  function placeOverlay() {
    const mapCanvas =
      document.getElementById("webgl-debug-canvas") ||
      [...document.querySelectorAll("canvas")].find((c) => !c.id.startsWith("ofc-"));
    if (!mapCanvas) return false;
    let anchor = mapCanvas;
    while (anchor.nextElementSibling?.id?.startsWith("ofc-") && anchor.nextElementSibling !== overlay) {
      anchor = anchor.nextElementSibling;
    }
    if (overlay.previousElementSibling !== anchor) anchor.after(overlay);
    return true;
  }

  let mouseX = innerWidth / 2;
  let mouseY = innerHeight / 2;
  window.addEventListener(
    "pointermove",
    (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    },
    { capture: true, passive: true }
  );

  function formatGold(n) {
    if (n >= 1e6) return (n / 1e6).toFixed(2) + "M";
    if (n >= 1e3) return Math.round(n / 1e3) + "K";
    return String(Math.round(n));
  }

  function label(text, x, y, color) {
    ctx.font = "8px 'OFC Pixel', ui-monospace, monospace";
    const w = Math.round(ctx.measureText(text).width + 10);
    const left = Math.round(clamp(x - w / 2, 4, innerWidth - w - 4));
    const top = Math.round(clamp(y - 8, 4, innerHeight - 20));
    ctx.fillStyle = "rgba(18,7,7,.9)";
    ctx.fillRect(left, top, w, 16);
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.strokeRect(left + 0.5, top + 0.5, w - 1, 15);
    ctx.fillStyle = color;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(text, left + w / 2, top + 9);
  }

  // Red (poor) -> amber -> green (best)
  function heatColor(k) {
    const stops = [
      [248, 113, 113],
      [252, 211, 77],
      [74, 222, 128],
    ];
    const s = clamp(k, 0, 1) * 2;
    const i = Math.min(1, Math.floor(s));
    const f = s - i;
    const c = stops[i].map((v, j) => Math.round(v + (stops[i + 1][j] - v) * f));
    return `rgb(${c[0]},${c[1]},${c[2]})`;
  }

  let visible = false;
  function draw() {
    const dpr = window.devicePixelRatio || 1;
    const w = Math.round(innerWidth * dpr);
    const h = Math.round(innerHeight * dpr);
    if (overlay.width !== w || overlay.height !== h) {
      overlay.width = w;
      overlay.height = h;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, innerWidth, innerHeight);
    if (!visible) return;

    // Messages appear next to the cursor, where you're looking
    if (!result || (!result.spots.length && !result.note)) {
      label("ESTIMATING PORT SPOTS…", mouseX, mouseY + 34, SALMON);
      return;
    }
    if (!result.spots.length) {
      label(result.note, mouseX, mouseY + 34, SALMON);
      return;
    }

    const gc = gameContext();
    if (!gc) return;
    const t = gc.transform;
    const origin = t.worldToScreenCoordinates({ x: 0, y: 0 });
    const s = t.scale || 1;
    const toScreen = (p) => ({ x: origin.x + (p.x + 0.5) * s, y: origin.y + (p.y + 0.5) * s });
    const range = result.max - result.min || 1;

    // Heat dots on your whole coast
    const dot = clamp(s * 2, 3, 7);
    for (const c of result.cands) {
      const p = toScreen(c);
      if (p.x < -10 || p.y < -10 || p.x > innerWidth + 10 || p.y > innerHeight + 10) continue;
      ctx.fillStyle = heatColor((c.score - result.min) / range);
      ctx.globalAlpha = 0.85;
      ctx.fillRect(Math.round(p.x - dot / 2), Math.round(p.y - dot / 2), dot, dot);
    }
    ctx.globalAlpha = 1;

    // Circles on the best spots
    const pulse = 0.5 + 0.5 * Math.sin(performance.now() / 300);
    result.spots.forEach((spot, i) => {
      const p = toScreen(spot);
      const best = i === 0;
      const color = best ? GREEN : AMBER;
      const r = (best ? 20 : 13) + pulse * 2;
      const onScreen = p.x > 0 && p.y > 0 && p.x < innerWidth && p.y < innerHeight;
      const text =
        spot.real >= 1
          ? `~${formatGold(spot.real)}/MIN`
          : "BEST SPOT · NO PORTS YET";

      if (!onScreen) {
        if (!best) return;
        // Off screen: marker at the screen edge, pointing to it
        const m = 40;
        const ex = clamp(p.x, m, innerWidth - m);
        const ey = clamp(p.y, m + 20, innerHeight - m);
        const ang = Math.atan2(p.y - ey, p.x - ex);
        ctx.save();
        ctx.translate(ex, ey);
        ctx.rotate(ang);
        ctx.fillStyle = "rgba(18,7,7,.85)";
        ctx.beginPath();
        ctx.moveTo(16, 0);
        ctx.lineTo(-8, -11);
        ctx.lineTo(-8, 11);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = GREEN;
        ctx.beginPath();
        ctx.moveTo(13, 0);
        ctx.lineTo(-6, -8);
        ctx.lineTo(-6, 8);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
        label(text, ex, ey - 22, GREEN);
        return;
      }

      ctx.lineWidth = best ? 4 : 3;
      ctx.strokeStyle = "rgba(18,7,7,.75)";
      ctx.beginPath();
      ctx.arc(p.x, p.y, r + 1.5, 0, Math.PI * 2);
      ctx.stroke();
      ctx.lineWidth = best ? 3 : 2;
      ctx.strokeStyle = color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = color;
      ctx.fillRect(Math.round(p.x) - 2, Math.round(p.y) - 2, 4, 4);
      if (best || spot.real >= 1) label(text, p.x, p.y - r - 14, color);
    });
  }

  // ---------- Loop ----------
  let lastHolding = false;
  let drawn = false;
  let failures = 0;
  function frame() {
    try {
      const holding = isEnabled() && holdingPort() && !!gameContext();
      if (holding && placeOverlay()) {
        // Fresh estimate when the port is picked up, then every few seconds
        const stale = !result || performance.now() - result.at > REFRESH_MS;
        if (!lastHolding || stale) refresh();
        visible = true;
      } else {
        visible = false;
        if (lastHolding) result = null; // port placed or dropped
      }
      lastHolding = holding;
      if (visible || drawn) {
        draw();
        drawn = visible;
      }
      failures = 0;
    } catch (err) {
      if (failures++ < 3) warn("draw failed:", err);
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
