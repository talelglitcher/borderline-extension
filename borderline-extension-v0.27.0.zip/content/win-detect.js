// Runs in the openfront.io page context ("MAIN" world).
//
// Detects the end-of-game result. Only scripts in the page's world can read
// the game's own variables (like the end screen's "isWin" flag); the
// extension's isolated scripts only see the HTML. So this script:
// - writes the result on the end screen as data-ofc-result="win" | "lose"
//   (used by hud.js's CSS to color the title);
// - fires a window "ofc-victory" event once when the victory screen appears
//   (hud.js plays the sound, victory-fx.js plays the 3D celebration).

(() => {
  const END_BOX = "div.fixed.z-\\[10010\\]"; // the end-of-game box, only rendered while shown
  let celebrated = false;

  function sync() {
    const modal = document.querySelector("win-modal");
    if (!modal) return;
    const result = modal.isWin ? "win" : "lose";
    if (modal.dataset.ofcResult !== result) modal.dataset.ofcResult = result;

    const shown = !!modal.querySelector(END_BOX);
    if (shown && modal.isWin && !celebrated) {
      celebrated = true;
      window.dispatchEvent(new CustomEvent("ofc-victory"));
    }
    if (!shown && !modal.isWin) celebrated = false; // ready for the next game
  }

  // React as soon as the end screen renders (before it's painted), plus a safety check
  let watched = null;
  setInterval(() => {
    const modal = document.querySelector("win-modal");
    if (modal && modal !== watched) {
      watched = modal;
      new MutationObserver(sync).observe(modal, { childList: true, subtree: true, characterData: true, attributes: true });
    }
    sync();
  }, 500);
})();
