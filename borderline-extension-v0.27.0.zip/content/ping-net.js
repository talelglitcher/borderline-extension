// Extension "isolated" world.
//
// Map Ping network: connects to the ping relay (address set in the popup)
// in the room of the current match, sends your pings and passes on the
// ones from other Borderline users. ping.js (page world) tells it which
// match you're in and does the drawing.

(() => {
  const KEEPALIVE_MS = 45000;

  let enabled = false;
  let server = "";
  let room = null;
  let ws = null;
  let retries = 0;
  let retryTimer = null;
  let keepAlive = null;

  const post = (msg) => window.postMessage({ source: "ofc-ping-net", ...msg }, location.origin);

  // "borderline-ping.x.workers.dev", "https://…" or "wss://…" -> "wss://…"
  function baseUrl(address) {
    let a = String(address || "").trim().replace(/\/+$/, "");
    if (!a) return "";
    if (/^https:\/\//i.test(a)) a = "wss://" + a.slice(8);
    else if (/^http:\/\//i.test(a)) a = "ws://" + a.slice(7);
    else if (!/^wss?:\/\//i.test(a)) a = "wss://" + a;
    try {
      return new URL(a).toString().replace(/\/+$/, "");
    } catch {
      return "";
    }
  }

  function wantedUrl() {
    const base = baseUrl(server);
    return enabled && base && room ? `${base}/room/${encodeURIComponent(room)}` : null;
  }

  function disconnect() {
    clearTimeout(retryTimer);
    clearInterval(keepAlive);
    if (ws) {
      ws.onclose = null;
      try {
        ws.close(1000);
      } catch {}
      ws = null;
    }
  }

  function update() {
    const url = wantedUrl();
    if (ws && ws.url === url) return;
    disconnect();
    if (url) connect(url);
  }

  function connect(url) {
    let socket;
    try {
      socket = new WebSocket(url);
    } catch {
      return;
    }
    ws = socket;
    socket.onopen = () => {
      retries = 0;
      clearInterval(keepAlive);
      keepAlive = setInterval(() => {
        if (socket.readyState === WebSocket.OPEN) socket.send("p");
      }, KEEPALIVE_MS);
    };
    socket.onmessage = (e) => {
      if (typeof e.data !== "string" || e.data.length > 300) return;
      try {
        const { x, y, n } = JSON.parse(e.data);
        post({ type: "in", x, y, n });
      } catch {}
    };
    socket.onclose = () => {
      clearInterval(keepAlive);
      if (ws !== socket) return;
      ws = null;
      // Still wanted: try again, waiting longer each time (up to 30 s)
      const again = wantedUrl();
      if (again) {
        const delay = Math.min(30000, 1000 * 2 ** retries++);
        retryTimer = setTimeout(update, delay);
      }
    };
  }

  // Messages from ping.js
  window.addEventListener("message", (e) => {
    // Checked by origin and tag (Firefox wraps "window" differently for extension scripts)
    if (e.origin !== location.origin) return;
    const d = e.data;
    if (!d || d.source !== "ofc-ping-main") return;
    if (d.type === "room") {
      room = typeof d.room === "string" && d.room ? d.room : null;
      retries = 0;
      update();
    } else if (d.type === "out" && ws?.readyState === WebSocket.OPEN) {
      const x = Math.round(Number(d.x));
      const y = Math.round(Number(d.y));
      if (!Number.isFinite(x) || !Number.isFinite(y)) return;
      ws.send(JSON.stringify({ x, y, n: String(d.n || "").slice(0, 40) }));
    }
  });

  chrome.storage.sync.get({ pings: false, pingServer: "" }, (s) => {
    enabled = !!s.pings;
    server = s.pingServer || "";
    update();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    if ("pings" in changes) enabled = !!changes.pings.newValue;
    if ("pingServer" in changes) server = changes.pingServer.newValue || "";
    if ("pings" in changes || "pingServer" in changes) {
      retries = 0;
      update();
    }
  });
})();
