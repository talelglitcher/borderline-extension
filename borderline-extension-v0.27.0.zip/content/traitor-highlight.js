// Runs in the openfront.io page context ("MAIN" world).
//
// Traitor Highlight module: the territory of every player who currently has
// the traitor debuff (they broke an alliance) pulses red on the map.
//
// The game paints territories with a WebGL shader that picks each tile's color
// from its owner. We add one step to that shader when the game creates it:
// if the owner is flagged as a traitor, blend a pulsing red over the color.
// The traitor flags come from the game's own player data (isTraitor), sent to
// the shader as a small texture indexed by player id.

(() => {
  const root = document.documentElement;
  const isEnabled = () => root.dataset.ofcTraitors === "on";

  const TEX_UNIT = 14; // free texture unit (troop-color.js uses 15)
  const TEX_WIDTH = 4096; // max player ids (the game's owner mask)
  const UPDATE_MS = 500;
  const PULSE_SPEED = 5.5; // pulses per ~second (radians/s factor)

  // ---------- Shader change ----------
  const MARK_A = "uHighlightBrighten";
  const MARK_B = "uSkinLayer";
  const MARK_END = "color.a = uTerritoryAlpha;";

  function patchFragment(src) {
    return src
      .replace(
        "out vec4 fragColor;",
        `uniform sampler2D uOfcTraitorTex;
uniform float uOfcTraitorOn;
uniform float uOfcTime;
out vec4 fragColor;`
      )
      .replace(
        MARK_END,
        `// Borderline: traitors' territory pulses red
  if (uOfcTraitorOn > 0.5 && texelFetch(uOfcTraitorTex, ivec2(int(owner), 0), 0).r > 0.5) {
    float pulse = 0.5 + 0.5 * sin(uOfcTime * ${PULSE_SPEED.toFixed(2)});
    color.rgb = mix(color.rgb, vec3(0.976, 0.235, 0.235), 0.2 + 0.5 * pulse);
  }
  ${MARK_END}`
      );
  }

  const GL = WebGL2RenderingContext.prototype;
  const patchedShaders = new WeakSet();
  const traitorPrograms = new WeakSet();

  const origShaderSource = GL.shaderSource;
  GL.shaderSource = function (shader, src) {
    if (typeof src === "string" && src.includes(MARK_A) && src.includes(MARK_B) && src.includes(MARK_END)) {
      src = patchFragment(src);
      patchedShaders.add(shader);
    }
    return origShaderSource.call(this, shader, src);
  };

  const origAttachShader = GL.attachShader;
  GL.attachShader = function (program, shader) {
    if (patchedShaders.has(shader)) traitorPrograms.add(program);
    return origAttachShader.call(this, program, shader);
  };

  const currentProgram = new WeakMap();
  const origUseProgram = GL.useProgram;
  GL.useProgram = function (program) {
    currentProgram.set(this, program);
    return origUseProgram.call(this, program);
  };

  // Track GPU state ourselves (asking with getParameter() forces a GPU sync)
  const activeUnit = new WeakMap();
  const origActiveTexture = GL.activeTexture;
  GL.activeTexture = function (unit) {
    activeUnit.set(this, unit);
    return origActiveTexture.call(this, unit);
  };
  const unpackBuffer = new WeakMap();
  const origBindBuffer = GL.bindBuffer;
  GL.bindBuffer = function (target, buffer) {
    if (target === this.PIXEL_UNPACK_BUFFER) unpackBuffer.set(this, buffer);
    return origBindBuffer.call(this, target, buffer);
  };

  // ---------- Traitor flags ----------
  function findGame() {
    const game = document.querySelector("player-info-overlay, control-panel")?.game;
    return game && typeof game.players === "function" ? game : null;
  }

  function fillFlags(data) {
    data.fill(0);
    const game = findGame();
    if (!game) return;
    for (const p of game.players()) {
      if (!p.isAlive?.() || !p.isTraitor?.()) continue;
      const id = p.smallID();
      if (id > 0 && id < TEX_WIDTH) data[id] = 1;
    }
  }

  const glState = new WeakMap();

  function prepare(gl, program) {
    let s = glState.get(gl);
    if (!s) {
      const prev = activeUnit.get(gl) ?? gl.TEXTURE0;
      gl.activeTexture(gl.TEXTURE0 + TEX_UNIT);
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texStorage2D(gl.TEXTURE_2D, 1, gl.R32F, TEX_WIDTH, 1);
      gl.activeTexture(prev);
      s = { tex, data: new Float32Array(TEX_WIDTH), lastUpdate: 0, locs: new WeakMap() };
      glState.set(gl, s);
    }

    let locs = s.locs.get(program);
    if (!locs) {
      locs = {
        tex: gl.getUniformLocation(program, "uOfcTraitorTex"),
        on: gl.getUniformLocation(program, "uOfcTraitorOn"),
        time: gl.getUniformLocation(program, "uOfcTime"),
      };
      s.locs.set(program, locs);
    }

    const enabled = isEnabled();
    gl.uniform1f(locs.on, enabled ? 1 : 0);
    gl.uniform1f(locs.time, performance.now() / 1000);
    gl.uniform1i(locs.tex, TEX_UNIT);

    const prev = activeUnit.get(gl) ?? gl.TEXTURE0;
    gl.activeTexture(gl.TEXTURE0 + TEX_UNIT);
    gl.bindTexture(gl.TEXTURE_2D, s.tex);
    const now = performance.now();
    if (enabled && now - s.lastUpdate > UPDATE_MS) {
      s.lastUpdate = now;
      try {
        fillFlags(s.data);
      } catch {
        s.data.fill(0);
      }
      const bound = unpackBuffer.get(gl) ?? null;
      if (bound) gl.bindBuffer(gl.PIXEL_UNPACK_BUFFER, null);
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, TEX_WIDTH, 1, gl.RED, gl.FLOAT, s.data);
      if (bound) gl.bindBuffer(gl.PIXEL_UNPACK_BUFFER, bound);
    }
    gl.activeTexture(prev);
  }

  for (const name of ["drawArrays", "drawElements", "drawArraysInstanced", "drawElementsInstanced"]) {
    const orig = GL[name];
    GL[name] = function (...args) {
      const program = currentProgram.get(this);
      if (program && traitorPrograms.has(program)) {
        try {
          prepare(this, program);
        } catch (err) {
          console.warn("[Borderline] traitor highlight:", err);
        }
      }
      return orig.apply(this, args);
    };
  }
})();
