// Runs in the openfront.io page context ("MAIN" world).
//
// Structure Highlight module: draws pulsing corner brackets around the
// structure types picked in the popup (cities, ports, SAM launchers…),
// on a transparent layer laid over the map.
// Mint = yours or a friendly player's (ally / teammate), coral = everyone else.

(() => {
  const root = document.documentElement;

  const FRIENDLY = "74, 222, 128"; // mint #4ADE80
  const HOSTILE = "248, 113, 113"; // coral #F87171
  const OUTLINE = "18, 7, 7"; // #120707

  const isEnabled = () => root.dataset.ofcHighlight === "on";
  const selectedTypes = () => (root.dataset.ofcHighlightTypes || "").split("|").filter(Boolean);

  // ---------- Overlay canvas ----------
  const overlay = document.createElement("canvas");
  overlay.id = "ofc-highlight-overlay";
  overlay.style.cssText = "position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;";
  const ctx = overlay.getContext("2d");

  // Keep the overlay right above the game's map canvas (and below the game UI).
  function placeOverlay() {
    const mapCanvas = [...document.querySelectorAll("canvas")].find((c) => c !== overlay);
    if (!mapCanvas) return false;
    if (overlay.previousElementSibling !== mapCanvas) {
      mapCanvas.after(overlay);
      overlay.style.zIndex = getComputedStyle(mapCanvas).zIndex;
    }
    return true;
  }

  function resize() {
    const dpr = window.devicePixelRatio || 1;
    const w = Math.round(innerWidth * dpr);
    const h = Math.round(innerHeight * dpr);
    if (overlay.width !== w || overlay.height !== h) {
      overlay.width = w;
      overlay.height = h;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function findGameContext() {
    const el = document.querySelector("player-info-overlay");
    const game = el?.game;
    const transform = el?.transform;
    if (!game || !transform || typeof game.units !== "function") return null;
    return { game, transform };
  }

  // ---------- Drawing ----------
  // Pixel-style corner brackets, like the Borderline logo.
  function brackets(x, y, half, arm, width, color) {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = "square";
    ctx.beginPath();
    for (const [sx, sy] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
      const cx = x + sx * half;
      const cy = y + sy * half;
      ctx.moveTo(cx, cy - sy * arm);
      ctx.lineTo(cx, cy);
      ctx.lineTo(cx - sx * arm, cy);
    }
    ctx.stroke();
  }

  function draw(now) {
    ctx.clearRect(0, 0, innerWidth, innerHeight);
    if (!isEnabled()) return;
    const types = selectedTypes();
    if (types.length === 0) return;
    const gc = findGameContext();
    if (!gc) return;
    const { game, transform } = gc;

    const me = game.myPlayer?.();
    const scale = transform.scale || 1; // screen pixels per map tile
    const pulse = (Math.sin(now / 260) + 1) / 2; // 0 → 1 → 0
    // The game draws structure icons ~46 px wide: frame them from the outside.
    const half = Math.max(28, scale * 3) + pulse * 3;
    const arm = Math.max(8, half * 0.4);
    const margin = half + 4;

    for (const unit of game.units(...types)) {
      if (!unit.isActive?.()) continue;
      const tile = unit.tile();
      const p = transform.worldToScreenCoordinates({ x: game.x(tile), y: game.y(tile) });
      const x = Math.round(p.x + scale / 2);
      const y = Math.round(p.y + scale / 2);
      if (x < -margin || y < -margin || x > innerWidth + margin || y > innerHeight + margin) continue;

      const owner = unit.owner();
      const friendly = me && (owner.smallID() === me.smallID() || me.isFriendly(owner));
      const rgb = friendly ? FRIENDLY : HOSTILE;
      const alpha = unit.isUnderConstruction?.() ? 0.45 : 0.75 + pulse * 0.25;

      // Soft glow fill, then dark outline, then colored brackets
      ctx.fillStyle = `rgba(${rgb}, ${0.08 + pulse * 0.08})`;
      ctx.fillRect(x - half, y - half, half * 2, half * 2);
      brackets(x, y, half, arm, 6, `rgba(${OUTLINE}, ${alpha * 0.8})`);
      brackets(x, y, half, arm, 3, `rgba(${rgb}, ${alpha})`);
    }
  }

  function frame(now) {
    try {
      if (placeOverlay()) {
        resize();
        draw(now);
      }
    } catch (err) {
      // The game may be between states (loading, game over): just skip this frame.
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
