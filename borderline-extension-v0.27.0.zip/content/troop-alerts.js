// Runs in the openfront.io page context ("MAIN" world).
//
// Troop Loss Alerts module: shows a pop-up at the bottom-left of the screen
// when a player or nation loses 90% or more of their troops within a short
// time (bots are ignored). Note: sending most of your army into an attack
// also counts, since those troops leave the player.
// Mint accent = you or a friendly player (ally / teammate), coral = others.
// Click an alert to move the camera to that player.

(() => {
  const root = document.documentElement;
  const isEnabled = () => root.dataset.ofcTroopAlerts === "on";

  const LOSS_RATIO = 0.9; // alert at 90% lost or more
  const WINDOW_MS = 30000; // compared with the player's peak over the last 30 s
  const MIN_PEAK = 20000; // ignore tiny players (2K troops as shown in game)
  const POLL_MS = 500;
  const TOAST_MS = 6000;
  const MAX_TOASTS = 4;

  // Game stores troops ×10 compared to what it shows (same format as the game)
  function formatTroops(raw) {
    const n = Math.max(0, raw / 10);
    if (n >= 1e6) return (n / 1e6).toFixed(2) + "M";
    if (n >= 1e5) return Math.floor(n / 1e3) + "K";
    if (n >= 1e3) return (n / 1e3).toFixed(1) + "K";
    return String(Math.floor(n));
  }

  function findGame() {
    const game = document.querySelector("player-info-overlay")?.game;
    return game && typeof game.players === "function" ? game : null;
  }

  // ---------- Detection ----------
  // smallID -> { samples: [[time, troops]], name }
  let tracked = new Map();
  let lastGame = null;

  function check() {
    if (!isEnabled()) {
      tracked.clear();
      return;
    }
    const game = findGame();
    if (!game) return;
    if (game !== lastGame) {
      tracked = new Map(); // new match
      lastGame = game;
    }

    const now = performance.now();
    const me = game.myPlayer?.();

    for (const p of game.players()) {
      // Bots (the many small AI "tribes") are ignored: only players and nations
      if (String(p.type?.()) === "BOT") continue;
      const id = p.smallID();
      const troops = p.isAlive() ? p.troops() : 0;
      let t = tracked.get(id);
      if (!t) {
        if (!p.isAlive()) continue;
        t = { samples: [] };
        tracked.set(id, t);
      }
      t.name = p.displayName();
      t.samples.push([now, troops]);
      while (t.samples.length && now - t.samples[0][0] > WINDOW_MS) t.samples.shift();

      const peak = Math.max(...t.samples.map((s) => s[1]));
      if (peak >= MIN_PEAK && troops <= peak * (1 - LOSS_RATIO)) {
        const friendly = !!me && (id === me.smallID() || me.isFriendly(p));
        showAlert({
          name: t.name,
          lost: Math.round((1 - troops / peak) * 100),
          from: peak,
          to: troops,
          friendly,
          you: !!me && id === me.smallID(),
          eliminated: !p.isAlive(),
          smallID: id,
        });
        // Start over from the current value: no repeat alert for the same drop
        t.samples = [[now, troops]];
      }
      if (!p.isAlive()) tracked.delete(id);
    }
  }
  setInterval(() => {
    try {
      check();
    } catch {
      // The game may be between states (loading, game over): try again next time
    }
  }, POLL_MS);

  // ---------- Pop-ups ----------
  let stack = null;

  function ensureStack() {
    if (stack?.isConnected) return stack;
    stack = document.createElement("div");
    stack.id = "ofc-troop-alerts";
    // Top layer (popover) so the game's own menus can't cover it
    stack.popover = "manual";
    stack.style.cssText = [
      "position:fixed",
      "inset:auto auto 16px 16px",
      "margin:0",
      "padding:0",
      "border:0",
      "background:none",
      "overflow:visible",
      "display:flex",
      "flex-direction:column",
      "gap:8px",
      "pointer-events:none",
      "z-index:2147483647",
    ].join(";");
    document.documentElement.append(stack);
    return stack;
  }

  // Move the camera to a player, using the game's own "go to player" camera
  // move (the same one used when clicking a player in the leaderboard)
  function goToPlayer(smallID) {
    const el = document.querySelector("player-info-overlay");
    const player = el?.game?.playerBySmallID?.(smallID);
    if (!player || typeof el.transform?.onGoToPlayer !== "function") return;
    if (!player.nameLocation?.()) return;
    el.transform.onGoToPlayer({ player });
  }

  function showAlert({ name, lost, from, to, friendly, you, eliminated, smallID }) {
    const container = ensureStack();
    const accent = friendly ? "#4ADE80" : "#F87171";

    const card = document.createElement("div");
    card.style.cssText = [
      "min-width:220px",
      "max-width:300px",
      "padding:10px 12px",
      "background:rgba(18,7,7,.94)",
      "border:2px solid #3a1616",
      `border-left:6px solid ${accent}`,
      "box-shadow:0 4px 14px rgba(0,0,0,.45)",
      "font:12px/1.45 ui-monospace, Consolas, monospace",
      "color:#f3e9e9",
    ].join(";");

    const title = document.createElement("div");
    title.style.cssText = "font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis";
    title.textContent = you ? `${name} (YOU)` : name;

    const line = document.createElement("div");
    line.style.cssText = `color:${accent};font-weight:bold;letter-spacing:.04em`;
    line.textContent = eliminated ? `ELIMINATED (-${lost}% TROOPS)` : `LOST ${lost}% OF TROOPS`;

    const detail = document.createElement("div");
    detail.style.cssText = "color:#a88484";
    detail.textContent = `${formatTroops(from)} → ${formatTroops(to)}`;

    card.append(title, line, detail);

    // Click: move the camera to that player
    card.title = "Go to this player";
    card.style.pointerEvents = "auto";
    card.style.cursor = "pointer";
    card.style.transition = "filter .15s, border-color .15s";
    // Hover: brighter, red frame (the colored left accent stays as is)
    const frame = (color) => {
      card.style.borderTopColor = color;
      card.style.borderRightColor = color;
      card.style.borderBottomColor = color;
    };
    card.addEventListener("mouseenter", () => {
      card.style.filter = "brightness(1.25)";
      frame("#F93C3C");
    });
    card.addEventListener("mouseleave", () => {
      card.style.filter = "";
      frame("#3a1616");
    });
    card.addEventListener("click", (e) => {
      e.stopPropagation();
      goToPlayer(smallID);
    });
    container.append(card);

    // Keep the newest at the bottom, drop the oldest beyond the limit
    while (container.children.length > MAX_TOASTS) container.firstElementChild.remove();

    try {
      if (container.matches(":popover-open")) container.hidePopover();
      container.showPopover(); // re-show so it stays above anything opened since
    } catch {}

    // Slide in from the left, then slide out after a few seconds
    const hidden = { opacity: 0, transform: "translateX(-24px)" };
    const shown = { opacity: 1, transform: "none" };
    card.animate([hidden, shown], { duration: 250, easing: "ease-out" });
    setTimeout(() => {
      card.animate([shown, hidden], { duration: 300, easing: "ease-in", fill: "forwards" }).finished.then(() => {
        card.remove();
        if (!container.children.length) {
          try {
            container.hidePopover();
          } catch {}
        }
      });
    }, TOAST_MS);
  }
})();
