// Extension "isolated" world.
//
// Ranked stats window on OpenFront's main screen (hidden during a match):
// a small movable window, in the Borderline style, that asks for your
// ofstats profile link (https://ofstats.io/player/<id>) and then shows your
// FFA elo, rank and the points left to the next rank.
//
// Data: the <id> in an ofstats link is your OpenFront player id. Elo and rank
// come from OpenFront's public ranked API (the same data ofstats uses).

(() => {
  const API = "https://api.openfront.io";
  const REFRESH_MS = 60000;
  const DIVISION = 200 / 3; // each rank = 200 points, split into 3 divisions

  // Ranks from lowest to highest: [api name, display name, color, start elo]
  const BASES = [
    ["iron", "Iron", "#9CA3AF", 1100],
    ["bronze", "Bronze", "#CD7F32", 1300],
    ["silver", "Silver", "#D1D5DB", 1500],
    ["gold", "Gold", "#FCD34D", 1700],
    ["platinum", "Platinum", "#5EEAD4", 1900],
    ["diamond", "Diamond", "#60A5FA", 2100],
    ["master", "Master", "#C084FC", 2300],
  ];
  const GRANDMASTER_AT = 2500;
  const GM_COLOR = "#F93C3C";

  // Every rank threshold, in order: { name, at }
  const THRESHOLDS = [];
  for (const [, name, , start] of BASES) {
    ["III", "II", "I"].forEach((div, i) => THRESHOLDS.push({ name: `${name} ${div}`, at: start + i * DIVISION }));
  }
  THRESHOLDS.push({ name: "Grandmaster", at: GRANDMASTER_AT });

  function baseOf(tier) {
    if (!tier) return null;
    if (tier === "Grandmaster") return ["grandmaster", "Grandmaster", GM_COLOR, GRANDMASTER_AT];
    return BASES.find(([, name]) => tier.startsWith(name)) || null;
  }

  function nextRank(elo) {
    return THRESHOLDS.find((t) => t.at > elo) || null;
  }

  // Progress inside the current division (0..1), for the bar
  function divisionProgress(elo) {
    const next = nextRank(elo);
    if (!next) return 1;
    const start = next.at - DIVISION;
    return Math.max(0, Math.min(1, (elo - start) / DIVISION));
  }

  function idFromLink(text) {
    const m = String(text).match(/ofstats\.io\/player\/([A-Za-z0-9_-]{4,})/) || String(text).trim().match(/^([A-Za-z0-9_-]{6,12})$/);
    return m ? m[1] : null;
  }

  async function getJSON(url) {
    const r = await fetch(url, { headers: { Accept: "application/json" } });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.json();
  }

  async function loadStats(id) {
    const profile = await getJSON(`${API}/public/player/${encodeURIComponent(id)}`);
    const r = profile.ffaRating;
    let name = profile.username || null;
    if (!name) {
      try {
        const of = await getJSON(`https://api.ofstats.io/players/${encodeURIComponent(id)}`);
        name = of.username || of.person?.displayName || null;
      } catch {}
    }
    if (!r) return { name: name || id, unranked: true };
    return {
      name: name || id,
      elo: r.rating,
      tier: r.tier,
      games: r.games,
      wins: r.wins,
    };
  }

  // ---------- Window ----------
  const LOGO = encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16"><circle cx="8" cy="8" r="6.5" fill="#120707" stroke="#F93C3C" stroke-width="1.5"/><circle cx="8" cy="8" r="3" fill="none" stroke="#C32E2E" stroke-width="1"/><rect x="7.5" y="1" width="1" height="7" fill="#F93C3C"/><path d="M3 13L13 3" stroke="#FFFFFF" stroke-width="1.2" stroke-dasharray="1.6 1.2"/></svg>`
  );

  const CSS = `
    #ofc-stats {
      position: fixed; margin: 0; padding: 0; inset: auto;
      width: 250px; z-index: 2147483000;
      background: rgba(18, 7, 7, .9); color: #f3e9e9;
      border: 2px solid #3a1616; border-top: 2px solid #F93C3C;
      box-shadow: 0 10px 30px rgba(0, 0, 0, .55), 0 0 18px rgba(249, 60, 60, .15);
      font: 12px/1.5 ui-sans-serif, system-ui, sans-serif;
      backdrop-filter: blur(4px); user-select: none; overflow: visible;
    }
    #ofc-stats .head {
      display: flex; align-items: center; gap: 8px; height: 26px; padding: 0 6px 0 28px;
      background: #1c0b0b url("data:image/svg+xml,${LOGO}") 7px center / 14px 14px no-repeat;
      border-bottom: 1px solid #3a1616; cursor: grab;
      font: 8px/26px "OFC Pixel", monospace; letter-spacing: .2em; color: #F93C3C;
    }
    #ofc-stats.dragging .head { cursor: grabbing; }
    #ofc-stats .head .title { flex: 1; }
    #ofc-stats .head button {
      width: 18px; height: 18px; padding: 0; border: 1px solid #3a1616; background: #120707;
      color: #E66161; font: 8px/1 "OFC Pixel", monospace; cursor: pointer;
    }
    #ofc-stats .head button:hover { border-color: #F93C3C; color: #fff; }
    #ofc-stats .body { padding: 10px 12px 12px; }
    #ofc-stats.collapsed .body { display: none; }
    #ofc-stats .label { font: 7px/1 "OFC Pixel", monospace; letter-spacing: .15em; color: #a88484; text-transform: uppercase; }
    #ofc-stats input {
      width: 100%; box-sizing: border-box; margin: 8px 0; padding: 7px 8px;
      background: #0b0404; color: #f3e9e9; border: 2px solid #3a1616; outline: none;
      font: 11px/1.2 ui-monospace, Consolas, monospace;
    }
    #ofc-stats input:focus { border-color: #F93C3C; }
    #ofc-stats .btn {
      width: 100%; padding: 8px; border: 0; cursor: pointer;
      background: #F93C3C; color: #fff; box-shadow: inset 0 -3px 0 #C32E2E;
      font: 8px/1 "OFC Pixel", monospace; letter-spacing: .1em;
    }
    #ofc-stats .btn:hover { background: #C32E2E; box-shadow: none; }
    #ofc-stats .link { background: none; border: 0; padding: 0; cursor: pointer; color: #a88484; font: 7px/1 "OFC Pixel", monospace; letter-spacing: .1em; }
    #ofc-stats .link:hover { color: #E66161; }
    #ofc-stats .error { margin-top: 6px; color: #F87171; font-size: 11px; }
    #ofc-stats .name { font-weight: 700; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 8px; }
    #ofc-stats .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 10px; }
    #ofc-stats .cell { background: rgba(28, 11, 11, .8); border: 1px solid #3a1616; padding: 6px 8px; }
    #ofc-stats .value { font: 14px/1.4 "OFC Pixel", monospace; margin-top: 4px; white-space: nowrap; }
    #ofc-stats .tier { font: 9px/1.5 "OFC Pixel", monospace; margin-top: 6px; }
    #ofc-stats .bar { height: 8px; background: #0b0404; border: 1px solid #3a1616; margin: 6px 0 4px; position: relative; }
    #ofc-stats .bar > div { position: absolute; inset: 0 auto 0 0; background: linear-gradient(90deg, #C32E2E, #F93C3C); }
    #ofc-stats .next { font-size: 11px; color: #E66161; }
    #ofc-stats .next b { color: #fff; }
    #ofc-stats .foot { display: flex; justify-content: space-between; margin-top: 10px; }
    #ofc-stats .muted { color: #a88484; font-size: 11px; }
  `;

  const STORE_KEYS = { link: "statsLink", pos: "statsWindowPos", collapsed: "statsCollapsed" };
  let state = { link: null, pos: null, collapsed: false };
  let win = null;
  let refreshTimer = null;

  function ensureStyle() {
    if (document.getElementById("ofc-stats-style")) return;
    const style = document.createElement("style");
    style.id = "ofc-stats-style";
    style.textContent = CSS;
    (document.head || document.documentElement).append(style);
  }

  function save(obj) {
    Object.assign(state, obj);
    const data = {};
    if ("link" in obj) data[STORE_KEYS.link] = obj.link;
    if ("pos" in obj) data[STORE_KEYS.pos] = obj.pos;
    if ("collapsed" in obj) data[STORE_KEYS.collapsed] = obj.collapsed;
    chrome.storage.sync.set(data);
  }

  function esc(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  }

  function place() {
    const p = state.pos || { x: innerWidth - 270, y: 90 };
    const x = Math.max(0, Math.min(innerWidth - 60, p.x));
    const y = Math.max(0, Math.min(innerHeight - 30, p.y));
    win.style.left = `${x}px`;
    win.style.top = `${y}px`;
  }

  function makeDraggable(handle) {
    let start = null;
    handle.addEventListener("pointerdown", (e) => {
      if (e.target.closest("button")) return;
      const r = win.getBoundingClientRect();
      start = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      handle.setPointerCapture(e.pointerId);
      win.classList.add("dragging");
    });
    handle.addEventListener("pointermove", (e) => {
      if (!start) return;
      state.pos = { x: e.clientX - start.dx, y: e.clientY - start.dy };
      place();
    });
    const end = () => {
      if (!start) return;
      start = null;
      win.classList.remove("dragging");
      save({ pos: state.pos });
    };
    handle.addEventListener("pointerup", end);
    handle.addEventListener("pointercancel", end);
  }

  function renderAsk(error = "") {
    const body = win.querySelector(".body");
    body.innerHTML = `
      <div class="label">Your ofstats profile link</div>
      <input type="text" placeholder="https://ofstats.io/player/..." spellcheck="false" value="${esc(state.link || "")}">
      <button class="btn" type="button">SHOW MY STATS</button>
      ${error ? `<div class="error">${esc(error)}</div>` : ""}
    `;
    const input = body.querySelector("input");
    const submit = () => {
      const id = idFromLink(input.value);
      if (!id) return renderAsk("That doesn't look like an ofstats profile link (https://ofstats.io/player/…).");
      save({ link: input.value.trim() });
      loadAndRender();
    };
    body.querySelector(".btn").addEventListener("click", submit);
    input.addEventListener("keydown", (e) => {
      e.stopPropagation(); // don't trigger game shortcuts while typing
      if (e.key === "Enter") submit();
    });
  }

  function renderStats(s) {
    const body = win.querySelector(".body");
    if (s.unranked) {
      body.innerHTML = `
        <div class="name">${esc(s.name)}</div>
        <div class="muted">No ranked FFA rating yet.</div>
        <div class="foot"><button class="link" data-act="change">CHANGE LINK</button><button class="link" data-act="refresh">REFRESH</button></div>`;
    } else {
      const base = baseOf(s.tier);
      const color = base ? base[2] : "#f3e9e9";
      const next = nextRank(s.elo);
      const progress = Math.round(divisionProgress(s.elo) * 100);
      const nextLine = next
        ? `<b>${(next.at - s.elo).toFixed(1)}</b> pts to <span style="color:${(baseOf(next.name) || [])[2] || "#fff"}">${esc(next.name)}</span>`
        : `Top rank reached`;
      body.innerHTML = `
        <div class="name" title="${esc(s.name)}">${esc(s.name)}</div>
        <div class="grid">
          <div class="cell"><div class="label">Elo</div><div class="value" title="${s.elo.toFixed(1)}">${Math.floor(s.elo)}</div></div>
          <div class="cell"><div class="label">Rank</div><div class="tier" style="color:${color}">${esc(s.tier || "Calibrating")}</div></div>
        </div>
        <div class="label">Next rank</div>
        <div class="bar"><div style="width:${progress}%"></div></div>
        <div class="next">${nextLine}</div>
        <div class="foot"><button class="link" data-act="change">CHANGE LINK</button><button class="link" data-act="refresh">REFRESH</button></div>`;
    }
    body.querySelector('[data-act="change"]').addEventListener("click", () => renderAsk());
    body.querySelector('[data-act="refresh"]').addEventListener("click", () => loadAndRender());
  }

  async function loadAndRender() {
    clearTimeout(refreshTimer);
    const id = idFromLink(state.link || "");
    if (!id) return renderAsk();
    win.querySelector(".body").innerHTML = `<div class="muted">Loading stats…</div>`;
    try {
      renderStats(await loadStats(id));
    } catch (err) {
      renderAsk(`Couldn't load this profile (${err.message}).`);
      return;
    }
    refreshTimer = setTimeout(loadAndRender, REFRESH_MS);
  }

  function build() {
    ensureStyle();
    win = document.createElement("div");
    win.id = "ofc-stats";
    win.popover = "manual"; // top layer: the main menu is shown in the top layer too
    win.innerHTML = `
      <div class="head"><span class="title">RANKED</span><button type="button" data-act="collapse" title="Minimize">–</button></div>
      <div class="body"></div>
    `;
    document.documentElement.append(win);
    if (state.collapsed) win.classList.add("collapsed");
    win.querySelector('[data-act="collapse"]').addEventListener("click", () => {
      win.classList.toggle("collapsed");
      save({ collapsed: win.classList.contains("collapsed") });
    });
    makeDraggable(win.querySelector(".head"));
    place();
    addEventListener("resize", place);
    loadAndRender();
  }

  // Only on the main screen: hidden while a match is on
  function inMatch() {
    return (
      !!document.getElementById("game-input-overlay") || // created when a match starts (spawn phase included)
      !!document.querySelector("control-panel > div.w-full") ||
      !!document.querySelector("win-modal div.fixed")
    );
  }

  function updateVisibility() {
    if (!win) return;
    const show = !inMatch();
    const open = win.matches(":popover-open");
    try {
      if (show && !open) win.showPopover();
      if (!show && open) win.hidePopover();
    } catch {}
  }

  chrome.storage.sync.get({ [STORE_KEYS.link]: null, [STORE_KEYS.pos]: null, [STORE_KEYS.collapsed]: false }, (saved) => {
    state = { link: saved[STORE_KEYS.link], pos: saved[STORE_KEYS.pos], collapsed: saved[STORE_KEYS.collapsed] };
    build();
    updateVisibility();
    setInterval(updateVisibility, 1000);
  });
})();
