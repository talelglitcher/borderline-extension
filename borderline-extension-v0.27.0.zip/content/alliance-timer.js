// Runs in the openfront.io page context ("MAIN" world). Always on.
//
// Alliance timers: shows the time left on each of your alliances directly on
// the map, just above the alliance (handshake) icon over your ally's name.
// Drawn in the same style as the game's name labels (same font, same dark
// fill, outline in the ally's territory color) so it blends in, and faded like
// the name when the mouse is over it. Turns coral in the last 30 seconds.

(() => {
  const TICKS_PER_SECOND = 10;
  const WARN_SECONDS = 30;

  // Same layout values the game uses to place name plates and status icons
  const FONT_SIZE = 48; // name atlas font size
  const FONT_BASE = 36; // name atlas baseline
  const NAME_SCALE_FACTOR = 0.4;
  const NAME_SCALE_CAP = 3;
  const ICON_TOP = 1.15; // top of the status icon row, in name-line heights above the name
  const TEXT_SIZE = 0.42; // timer height compared to the name's line height
  const HOVER_FADE = 0.5; // same fade the game applies to a hovered name plate
  const MIN_TEXT_PX = 7; // hide when zoomed too far out

  // Name fill shades used by the game (0 = black): players, nations, bots
  const NAME_SHADE = { HUMAN: 0.1, NATION: 0.3, BOT: 0.4 };

  const overlay = document.createElement("canvas");
  overlay.id = "ofc-alliance-timers";
  overlay.style.cssText = "position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;";
  const ctx = overlay.getContext("2d");

  // Keep the overlay right above the game's map canvas (and below the game UI)
  function placeOverlay() {
    const mapCanvas = document.getElementById("webgl-debug-canvas") ||
      [...document.querySelectorAll("canvas")].find((c) => !c.id.startsWith("ofc-"));
    if (!mapCanvas) return false;
    if (overlay.previousElementSibling !== mapCanvas) mapCanvas.after(overlay);
    return true;
  }

  function resize() {
    const dpr = window.devicePixelRatio || 1;
    const w = Math.round(innerWidth * dpr);
    const h = Math.round(innerHeight * dpr);
    if (overlay.width !== w || overlay.height !== h) {
      overlay.width = w;
      overlay.height = h;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function gameContext() {
    const el = document.querySelector("player-info-overlay");
    const game = el?.game;
    const transform = el?.transform;
    if (!game || !transform || typeof game.myPlayer !== "function") return null;
    return { game, transform };
  }

  // Same rounding as the game's own alliance countdown (whole seconds, rounded down)
  function formatTime(ticksLeft) {
    const s = Math.max(0, Math.floor(ticksLeft / TICKS_PER_SECOND));
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  }

  function territoryColor(player) {
    try {
      return player.territoryColor().toHex();
    } catch {
      return "#808080";
    }
  }

  // Mouse position, to fade the timer like the game fades a hovered name plate
  let mouseX = -1e9;
  let mouseY = -1e9;
  window.addEventListener(
    "pointermove",
    (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    },
    { capture: true, passive: true }
  );

  function draw() {
    ctx.clearRect(0, 0, innerWidth, innerHeight);
    const gc = gameContext();
    if (!gc) return;
    const { game, transform } = gc;
    const me = game.myPlayer();
    if (!me?.isAlive?.()) return;

    const alliances = me.alliances?.() || [];
    if (!alliances.length) return;

    const scale = transform.scale || 1; // screen px per map tile
    const origin = transform.worldToScreenCoordinates({ x: 0, y: 0 });
    const ticks = game.ticks();

    for (const a of alliances) {
      const ally = game.player?.(a.other);
      if (!ally?.isAlive?.()) continue;
      const loc = ally.nameLocation?.();
      if (!loc) continue;

      // Same sizing as the game's name / status-icon shaders
      const baseSize = Math.max(1, Math.floor(loc.size));
      const nameSize = Math.max(4, Math.floor(baseSize * NAME_SCALE_FACTOR));
      const nameScale = Math.min(baseSize * 0.25, NAME_SCALE_CAP);
      const nameWorldScale = (nameSize * nameScale) / FONT_SIZE;
      const linePx = FONT_BASE * nameWorldScale * scale;

      const x = origin.x + loc.x * scale;
      const nameY = origin.y + loc.y * scale;
      const y = nameY - linePx * ICON_TOP - 1; // bottom of the timer, just above the icons
      const fontPx = Math.round(linePx * TEXT_SIZE);
      if (fontPx < MIN_TEXT_PX) continue;
      if (x < -80 || y < -30 || x > innerWidth + 80 || y > innerHeight + 30) continue;

      // Faded like the name plate when the mouse is over it
      ctx.font = `700 ${Math.round(FONT_SIZE * nameWorldScale * scale)}px Overpass, sans-serif`;
      const nameHalf = ctx.measureText(ally.displayName()).width / 2 + linePx * 0.2;
      const hovered =
        Math.abs(mouseX - x) <= nameHalf && mouseY >= y - fontPx && mouseY <= nameY + linePx * 1.6;
      ctx.globalAlpha = hovered ? HOVER_FADE : 1;

      const ticksLeft = a.expiresAt - ticks;
      const warn = ticksLeft / TICKS_PER_SECOND <= WARN_SECONDS;
      const shade = Math.round((NAME_SHADE[String(ally.type?.())] ?? 0.3) * 255);

      const text = formatTime(ticksLeft);
      ctx.font = `700 ${fontPx}px Overpass, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "bottom";
      ctx.lineJoin = "round";
      ctx.lineWidth = Math.max(2, fontPx * 0.18);
      ctx.strokeStyle = territoryColor(ally);
      ctx.strokeText(text, x, y);
      ctx.fillStyle = warn ? "#C0392B" : `rgb(${shade}, ${shade}, ${shade})`;
      ctx.fillText(text, x, y);
    }
    ctx.globalAlpha = 1;
  }

  function frame() {
    try {
      if (placeOverlay()) {
        resize();
        draw();
      }
    } catch {
      // The game may be between states (loading, game over): skip this frame
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
