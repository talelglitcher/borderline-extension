// S'exécute dans le contexte de la page openfront.io (monde "MAIN").
//
// Nombre de troupes sous les pseudos, sur la carte :
// - un peu plus grand ;
// - coloré selon le remplissage de l'armée (troupes / troupes max) :
//   vert à 70 % et plus, rouge à 25 % et moins, dégradé (via jaune) entre les deux.
//
// Le jeu dessine les noms avec un shader WebGL. On modifie le code de ce shader
// au moment où le jeu le crée, et on lui fournit une petite texture contenant
// le ratio de troupes de chaque joueur (indexée par son identifiant).

(() => {
  const root = document.documentElement;

  const SIZE_BOOST = 1.1; // taille du nombre de troupes : +10 %
  const GREEN_AT = 0.7;
  const RED_AT = 0.25;
  const TEX_UNIT = 15; // unité de texture libre (le jeu n'en utilise que quelques-unes)
  const TEX_WIDTH = 4096; // nombre max d'identifiants de joueurs
  const UPDATE_MS = 500;

  const isEnabled = () => root.dataset.ofcTroopColors === "on";

  // ---------- Modification des shaders ----------
  const VS_SIZE = "worldScale *= uTroopSizeMultiplier;";
  const VS_END = "vNameShade = pd3.z;";
  const FS_FILL = "vec3 fillColor = mix(defaultFill, vPlayerColor.rgb, uFillUsePlayerColor);";
  const FS_BORDER = "vec3 borderColor = mix(nightOutlineColor, vPlayerColor.rgb, uOutlineUsePlayerColor);";

  function patchVertex(src) {
    return src
      .replace(
        "void main() {",
        `uniform sampler2D uOfcTroopRatio;
uniform float uOfcTroopEnabled;
out vec4 vOfcTroop;

void main() {
  vOfcTroop = vec4(0.0);`
      )
      .replace(VS_SIZE, `worldScale *= uTroopSizeMultiplier * mix(1.0, ${SIZE_BOOST.toFixed(3)}, uOfcTroopEnabled);`)
      .replace(
        VS_END,
        `${VS_END}
  if (lineIdx == 1 && uOfcTroopEnabled > 0.5) {
    float ratio = texelFetch(uOfcTroopRatio, ivec2(int(smallID), 0), 0).r;
    if (ratio >= 0.0) {
      float k = clamp((ratio - ${RED_AT.toFixed(3)}) / ${(GREEN_AT - RED_AT).toFixed(3)}, 0.0, 1.0);
      // Softer palette: coral #F87171 -> amber #FCD34D -> mint #4ADE80
      vec3 red = vec3(0.973, 0.443, 0.443);
      vec3 yellow = vec3(0.988, 0.827, 0.302);
      vec3 green = vec3(0.290, 0.871, 0.502);
      k = smoothstep(0.0, 1.0, k);
      vec3 c = k < 0.5 ? mix(red, yellow, k * 2.0) : mix(yellow, green, (k - 0.5) * 2.0);
      vOfcTroop = vec4(c, 1.0);
    }
  }`
      );
  }

  function patchFragment(src) {
    return src
      .replace("out vec4 fragColor;", "in vec4 vOfcTroop;\nout vec4 fragColor;")
      .replace(FS_FILL, `${FS_FILL}\n  fillColor = mix(fillColor, vOfcTroop.rgb, vOfcTroop.a);`)
      // Contour noir autour du nombre coloré, pour qu'il reste lisible sur tous les territoires
      .replace(FS_BORDER, `${FS_BORDER}\n    borderColor = mix(borderColor, vec3(0.07, 0.07, 0.09), vOfcTroop.a);`);
  }

  const GL = WebGL2RenderingContext.prototype;
  const patchedVertexShaders = new WeakSet();
  const troopPrograms = new WeakSet();

  const origShaderSource = GL.shaderSource;
  GL.shaderSource = function (shader, src) {
    if (typeof src === "string") {
      if (src.includes(VS_SIZE) && src.includes(VS_END)) {
        src = patchVertex(src);
        patchedVertexShaders.add(shader);
      } else if (src.includes(FS_FILL) && src.includes(FS_BORDER)) {
        src = patchFragment(src);
      }
    }
    return origShaderSource.call(this, shader, src);
  };

  const origAttachShader = GL.attachShader;
  GL.attachShader = function (program, shader) {
    if (patchedVertexShaders.has(shader)) troopPrograms.add(program);
    return origAttachShader.call(this, program, shader);
  };

  const currentProgram = new WeakMap(); // gl -> programme en cours
  const origUseProgram = GL.useProgram;
  GL.useProgram = function (program) {
    currentProgram.set(this, program);
    return origUseProgram.call(this, program);
  };

  // Track the active texture unit and the pixel-unpack buffer ourselves:
  // asking the GPU with getParameter() forces a sync and can cause hitches.
  const activeUnit = new WeakMap(); // gl -> active texture unit (gl.TEXTUREn)
  const origActiveTexture = GL.activeTexture;
  GL.activeTexture = function (unit) {
    activeUnit.set(this, unit);
    return origActiveTexture.call(this, unit);
  };
  const unpackBuffer = new WeakMap(); // gl -> bound PIXEL_UNPACK_BUFFER
  const origBindBuffer = GL.bindBuffer;
  GL.bindBuffer = function (target, buffer) {
    if (target === this.PIXEL_UNPACK_BUFFER) unpackBuffer.set(this, buffer);
    return origBindBuffer.call(this, target, buffer);
  };

  // ---------- Données de troupes ----------
  const glState = new WeakMap(); // gl -> { tex, data, lastUpdate, locs }

  function findGame() {
    const el = document.querySelector("control-panel, player-info-overlay, game-right-sidebar");
    const game = el?.game;
    return game && typeof game.players === "function" && typeof game.config === "function" ? game : null;
  }

  function fillRatios(data) {
    data.fill(-1);
    const game = findGame();
    if (!game) return;
    const config = game.config();
    for (const p of game.players()) {
      if (!p.isAlive()) continue;
      const id = p.smallID();
      if (id < 0 || id >= TEX_WIDTH) continue;
      const max = config.maxTroops(p);
      data[id] = max > 0 ? p.troops() / max : 1;
    }
  }

  function prepare(gl, program) {
    let s = glState.get(gl);
    if (!s) {
      const prevUnit = activeUnit.get(gl) ?? gl.TEXTURE0;
      gl.activeTexture(gl.TEXTURE0 + TEX_UNIT);
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texStorage2D(gl.TEXTURE_2D, 1, gl.R32F, TEX_WIDTH, 1);
      gl.activeTexture(prevUnit);
      s = { tex, data: new Float32Array(TEX_WIDTH).fill(-1), lastUpdate: 0, locs: new WeakMap() };
      glState.set(gl, s);
    }

    let locs = s.locs.get(program);
    if (!locs) {
      locs = {
        sampler: gl.getUniformLocation(program, "uOfcTroopRatio"),
        enabled: gl.getUniformLocation(program, "uOfcTroopEnabled"),
      };
      s.locs.set(program, locs);
    }

    const enabled = isEnabled();
    gl.uniform1f(locs.enabled, enabled ? 1 : 0);
    gl.uniform1i(locs.sampler, TEX_UNIT);

    const prevUnit = activeUnit.get(gl) ?? gl.TEXTURE0;
    gl.activeTexture(gl.TEXTURE0 + TEX_UNIT);
    gl.bindTexture(gl.TEXTURE_2D, s.tex);

    const now = performance.now();
    if (enabled && now - s.lastUpdate > UPDATE_MS) {
      s.lastUpdate = now;
      try {
        fillRatios(s.data);
      } catch (err) {
        s.data.fill(-1);
      }
      const boundUnpack = unpackBuffer.get(gl) ?? null;
      if (boundUnpack) gl.bindBuffer(gl.PIXEL_UNPACK_BUFFER, null);
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, TEX_WIDTH, 1, gl.RED, gl.FLOAT, s.data);
      if (boundUnpack) gl.bindBuffer(gl.PIXEL_UNPACK_BUFFER, boundUnpack);
    }
    gl.activeTexture(prevUnit);
  }

  for (const name of ["drawArraysInstanced", "drawElementsInstanced"]) {
    const orig = GL[name];
    GL[name] = function (...args) {
      const program = currentProgram.get(this);
      if (program && troopPrograms.has(program)) {
        try {
          prepare(this, program);
        } catch (err) {
          console.warn("[OpenFront Companion] couleur des troupes :", err);
        }
      }
      return orig.apply(this, args);
    };
  }
})();
