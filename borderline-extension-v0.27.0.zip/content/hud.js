// Extension "isolated" world.
//
// Borderline HUD (always on): restyles the game's interface in the
// extension's look:
// - bottom panel (troops, gold, attack ratio, build bar) with a Borderline
//   header strip and a marker at 42% on the troop bar;
// - in-game leaderboard (top-left);
// - attack pop-ups shown above the bottom panel;
// - hovered player info bar (top center), game controls (top right) and
//   event messages and alliance requests (bottom right);
// - end-of-game screen (win & lose);
// - player info window and emoji window;
// - the game's gold icon is replaced by an animated pixel gold coin.

(() => {
  const FONT_URL = chrome.runtime.getURL("fonts/press-start-2p.ttf");

  // Mini radar logo (same design as the extension icon), inline so it needs no file access
  const LOGO = encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" shape-rendering="crispEdges">` +
      `<circle cx="8" cy="8" r="6.5" fill="#120707" stroke="#F93C3C" stroke-width="1.5" shape-rendering="geometricPrecision"/>` +
      `<circle cx="8" cy="8" r="3" fill="none" stroke="#C32E2E" stroke-width="1" shape-rendering="geometricPrecision"/>` +
      `<rect x="7.5" y="1" width="1" height="7" fill="#F93C3C"/>` +
      `<path d="M3 13L13 3" stroke="#FFFFFF" stroke-width="1.2" stroke-dasharray="1.6 1.2" shape-rendering="geometricPrecision"/>` +
      `</svg>`
  );

  // Header strip with the logo, used on the panels
  // Header strip with just the radar logo (no text)
  const HEADER = `
      content: "";
      display: block;
      height: 18px;
      background: #1c0b0b url("data:image/svg+xml,${LOGO}") 7px center / 13px 13px no-repeat;
      border-bottom: 1px solid #3a1616;
      pointer-events: none;
  `;

  // Size of the themed panels (1 = game's size) and opacity of their background
  const SCALE = 0.85;
  const GOLD_SCALE = 1.4; // size of the gold coin icon compared to the game's icon
  const BG_ALPHA = 0.72;
  const BLUE = "#5AB0FF"; // text of your own attacks

  // Bottom panel: the container holding <control-panel>. During a match the
  // control panel's root is "div.w-full" (outside a match it's an empty
  // "div.hidden"), so this matches only while a match is on — with no delay.
  const PANEL = "div:has(> control-panel > div.w-full)";

  const LB = "game-left-sidebar aside"; // leaderboard panel
  const ATTACK = "attacks-display .bg-gray-800\\/92"; // one attack pop-up
  const INFO = "player-info-overlay .bg-gray-800\\/92"; // hovered player bar (top center)
  const CONTROLS = "game-right-sidebar aside"; // timer / speed / pause… (top right)
  const EVENTS = "events-display"; // event messages (bottom right)
  const REQUEST = "actionable-events .bg-gray-800\\/92"; // alliance requests / renewals (bottom right)
  const END_BOX = "div.fixed.z-\\[10010\\]"; // the end-of-game box (only rendered while shown)
  const END = `win-modal ${END_BOX}`; // end-of-game screen (win & lose)
  const PP_CARD = "player-panel div.bg-zinc-900\\/95"; // player info window (click on a player)
  const EMOJI_CARD = "emoji-table div.bg-zinc-900\\/95"; // emoji picker window
  const WINDOWS = `:is(${PP_CARD}, ${EMOJI_CARD})`;

  const CSS = `
    @font-face { font-family: "OFC Pixel"; src: url("${FONT_URL}") format("truetype"); }

    /* ================= Bottom panel ================= */
    ${PANEL} {
      position: relative !important;
      zoom: ${SCALE};
      background: rgba(18, 7, 7, ${BG_ALPHA}) !important;
      border: 2px solid #3a1616 !important;
      border-top-color: #F93C3C !important;
      border-radius: 0 !important;
      box-shadow: 0 -2px 14px rgba(249, 60, 60, .18), 0 8px 20px rgba(0, 0, 0, .5) !important;
    }
    ${PANEL}::before { ${HEADER} }

    ${PANEL} .rounded-md, ${PANEL} .rounded-sm, ${PANEL} .rounded-lg { border-radius: 0 !important; }
    ${PANEL} .border-gray-600, ${PANEL} .border-slate-500 { border-color: #3a1616 !important; }
    ${PANEL} .unit-display-root { border-top-color: #3a1616 !important; }
    ${PANEL} .bg-gray-900\\/60 { background: rgba(11, 4, 4, .7) !important; }

    /* Troop bar: logo red, lighter part in salmon */
    ${PANEL} .bg-malibu-blue {
      background: linear-gradient(90deg, #C32E2E, #F93C3C) !important;
      box-shadow: inset 0 -3px 0 rgba(0, 0, 0, .25);
    }
    ${PANEL} .bg-aquarius { background: #E66161 !important; }

    /* Marker at 42% of max troops (about where troops regrow fastest) */
    ${PANEL} .bg-gray-900\\/60:has(.bg-malibu-blue)::after {
      content: "";
      position: absolute;
      top: 0;
      bottom: 0;
      left: 42%;
      width: 2px;
      margin-left: -1px;
      background: #FFFFFF;
      box-shadow: 0 0 0 1px rgba(18, 7, 7, .85), 0 0 6px rgba(255, 255, 255, .5);
      pointer-events: none;
      z-index: 1;
    }
    /* Keep the troop numbers above the marker */
    ${PANEL} .bg-gray-900\\/60 > .inset-0 { z-index: 2; }

    ${PANEL} input[type="range"] { accent-color: #F93C3C !important; }
    ${PANEL} .border-slate-500 { transition: border-color .15s, background .15s; }
    ${PANEL} .border-slate-500:hover { border-color: #F93C3C !important; background: rgba(249, 60, 60, .08) !important; }

    /* ================= Leaderboard (top-left) ================= */
    ${LB} {
      zoom: ${SCALE};
      background: rgba(18, 7, 7, ${BG_ALPHA}) !important;
      border: 2px solid #3a1616 !important;
      border-top-color: #F93C3C !important;
      border-left: 0 !important;
      border-radius: 0 !important;
      box-shadow: 0 8px 20px rgba(0, 0, 0, .5), 2px 0 14px rgba(249, 60, 60, .12) !important;
      scrollbar-color: #3a1616 transparent;
    }
    ${LB}::before { ${HEADER} margin: -8px -8px 6px; }

    ${LB} .rounded-md, ${LB} .rounded-lg, ${LB} .rounded-br-lg { border-radius: 0 !important; }
    ${LB} .bg-gray-800\\/85 { background: rgba(11, 4, 4, .45) !important; }
    ${LB} .stats-table-header { background: rgba(28, 11, 11, .8) !important; }
    ${LB} .border-slate-500, ${LB} .border-b-slate-500, ${LB} .border-l-slate-500 { border-color: #3a1616 !important; }
    ${LB} .bg-gray-700\\/50 { background: #1c0b0b !important; }
    ${LB} .bg-gray-700\\/50:hover { background: rgba(249, 60, 60, .15) !important; }
    ${LB} .stats-table-scroll { scrollbar-color: #3a1616 transparent; }
    ${LB} .stats-table-row:hover { background: rgba(249, 60, 60, .10) !important; }
    ${LB} .stats-table-pinned-row {
      background: rgba(249, 60, 60, .16) !important;
      box-shadow: inset 3px 0 0 #F93C3C;
    }
    ${LB} .text-sky-300 { color: #E66161 !important; }
    ${LB} button:hover { color: #F87171 !important; }

    /* ================= Attack pop-ups (above the bottom panel) ================= */
    /* Your attacks (outgoing, by land or boat): blue. Attacks on you: red. */
    ${ATTACK} {
      background: rgba(18, 7, 7, ${BG_ALPHA}) !important;
      border: 2px solid #3a1616 !important;
      border-left: 4px solid #F93C3C !important;
      border-radius: 0 !important;
      box-shadow: 0 4px 12px rgba(0, 0, 0, .45) !important;
      padding-top: 3px !important;
      padding-bottom: 3px !important;
      transition: border-color .15s, background .15s !important;
    }
    ${ATTACK}:hover { background: rgba(28, 11, 11, .9) !important; }
    ${ATTACK} button { font-weight: 600; font-variant-numeric: tabular-nums; }

    ${ATTACK}:has(.text-aquarius) {
      border-left-color: ${BLUE} !important;
      box-shadow: 0 4px 12px rgba(0, 0, 0, .45), inset 0 0 14px rgba(90, 176, 255, .08) !important;
    }
    ${ATTACK}:has(.text-aquarius):hover { border-color: #1e3550 !important; border-left-color: ${BLUE} !important; }
    ${ATTACK} .text-aquarius { color: ${BLUE} !important; }

    ${ATTACK}:has(.text-red-400) {
      border-left-color: #F87171 !important;
      box-shadow: 0 4px 12px rgba(0, 0, 0, .45), inset 0 0 14px rgba(248, 113, 113, .08) !important;
    }
    ${ATTACK}:has(.text-red-400):hover { border-color: #4a1c1c !important; border-left-color: #F87171 !important; }
    ${ATTACK} .text-red-400 { color: #F87171 !important; }
    ${ATTACK} .text-slate-300 { color: #a88484 !important; } /* boat arrival time */

    /* Cancel / retaliate buttons: small square keys */
    ${ATTACK} button.ml-auto, ${ATTACK} button.shrink-0 {
      padding: 0 4px;
      border: 1px solid #3a1616;
      background: #1c0b0b;
      line-height: 1.3;
      transition: border-color .15s, background .15s;
    }
    ${ATTACK} button.ml-auto:hover, ${ATTACK} button.shrink-0:hover { border-color: #F93C3C; background: rgba(249, 60, 60, .15); }

    /* ================= Player info bar (top center, hovered player) ================= */
    ${INFO} {
      background: rgba(18, 7, 7, ${BG_ALPHA}) !important;
      border: 2px solid #3a1616 !important;
      border-top: 0 !important;
      border-bottom-color: #F93C3C !important;
      border-radius: 0 !important;
      box-shadow: 0 8px 20px rgba(0, 0, 0, .45), 0 2px 14px rgba(249, 60, 60, .12) !important;
    }
    ${INFO} .rounded-md, ${INFO} .rounded-lg, ${INFO} .rounded-sm { border-radius: 0 !important; }
    ${INFO} .border-gray-600, ${INFO} .border-gray-500 { border-color: #3a1616 !important; }
    ${INFO} .bg-gray-900\\/60 { background: rgba(11, 4, 4, .7) !important; }
    ${INFO} .bg-sky-700 { background: #E66161 !important; }
    ${INFO} .bg-malibu-blue { background: linear-gradient(90deg, #C32E2E, #F93C3C) !important; }

    /* ================= Game controls (top right: timer, speed, pause…) ================= */
    ${CONTROLS} {
      background: rgba(18, 7, 7, ${BG_ALPHA}) !important;
      border: 2px solid #3a1616 !important;
      border-top: 0 !important;
      border-right: 0 !important;
      border-bottom-color: #F93C3C !important;
      border-radius: 0 !important;
      box-shadow: 0 8px 20px rgba(0, 0, 0, .45) !important;
    }
    ${CONTROLS} .rounded-md, ${CONTROLS} .rounded-lg, ${CONTROLS} .rounded-sm { border-radius: 0 !important; }
    ${CONTROLS} [class*="bg-gray-"], ${CONTROLS} [class*="bg-slate-"] { background-color: #1c0b0b !important; }
    ${CONTROLS} [class*="border-gray-"], ${CONTROLS} [class*="border-slate-"] { border-color: #3a1616 !important; }
    ${CONTROLS} button:hover, ${CONTROLS} [role="button"]:hover { filter: drop-shadow(0 0 4px rgba(249, 60, 60, .8)); }

    /* ================= Event messages (bottom right) ================= */
    ${EVENTS} [class*="bg-gray-800"], ${EVENTS} [class*="bg-gray-900"], ${EVENTS} [class*="bg-slate-8"] {
      background: rgba(18, 7, 7, ${BG_ALPHA}) !important;
      border-color: #3a1616 !important;
      border-radius: 0 !important;
    }
    ${EVENTS} [class*="bg-gray-800"] { box-shadow: inset 4px 0 0 #F93C3C, 0 4px 12px rgba(0, 0, 0, .45) !important; }
    ${EVENTS} .rounded-md, ${EVENTS} .rounded-lg, ${EVENTS} .rounded-sm,
    ${EVENTS} [class*="rounded-"] { border-radius: 0 !important; }
    ${EVENTS} [class*="border-gray-"], ${EVENTS} [class*="border-slate-"] { border-color: #3a1616 !important; }

    /* ================= Alliance requests & renewals (bottom right) ================= */
    ${REQUEST} {
      background: rgba(18, 7, 7, ${BG_ALPHA}) !important;
      border: 2px solid #3a1616 !important;
      border-left: 4px solid #F93C3C !important;
      border-radius: 0 !important;
      box-shadow: 0 4px 12px rgba(0, 0, 0, .45), 0 0 14px rgba(249, 60, 60, .12) !important;
    }
    ${REQUEST} button.rounded-sm {
      border-radius: 0 !important;
      border: 2px solid #3a1616 !important;
      background: #1c0b0b !important;
      color: #f3e9e9 !important;
      font-weight: 600;
      letter-spacing: .03em;
      transition: border-color .15s, background .15s, filter .15s !important;
    }
    ${REQUEST} button.rounded-sm:hover { border-color: #E66161 !important; filter: brightness(1.15); }
    /* Accept: mint */
    ${REQUEST} button.bg-green-600 {
      background: rgba(74, 222, 128, .16) !important;
      border-color: #4ADE80 !important;
      color: #4ADE80 !important;
    }
    ${REQUEST} button.bg-green-600:hover { background: rgba(74, 222, 128, .28) !important; border-color: #4ADE80 !important; }
    /* Reject / ignore: coral */
    ${REQUEST} button.bg-blue-500 {
      background: rgba(248, 113, 113, .14) !important;
      border-color: #F87171 !important;
      color: #F87171 !important;
    }
    ${REQUEST} button.bg-blue-500:hover { background: rgba(248, 113, 113, .26) !important; border-color: #F87171 !important; }

    /* ================= End-of-game screen (win & lose) ================= */
    ${END} {
      background: rgba(18, 7, 7, .88) !important;
      border: 2px solid #3a1616 !important;
      border-top: 3px solid #F93C3C !important;
      border-radius: 0 !important;
      box-shadow: 0 20px 60px rgba(0, 0, 0, .6), 0 0 40px rgba(249, 60, 60, .18) !important;
    }
    ${END}::before { ${HEADER} margin: -1rem -1rem .75rem; flex-shrink: 0; }
    @media (min-width: 768px) { ${END}::before { margin: -1.5rem -1.5rem 1rem; } }

    /* Title in the logo's pixel font: mint for a win, coral otherwise */
    ${END} > h2 {
      font-family: "OFC Pixel", monospace !important;
      font-size: 20px !important;
      line-height: 1.4 !important;
      letter-spacing: .08em;
      text-transform: uppercase;
      color: #F87171 !important;
      text-shadow: 0 2px 0 #120707, 0 0 18px rgba(248, 113, 113, .35);
    }
    win-modal[data-ofc-result="win"] ${END_BOX} > h2 {
      color: #4ADE80 !important;
      text-shadow: 0 2px 0 #120707, 0 0 18px rgba(74, 222, 128, .35);
    }

    /* Inner blocks (XP, rating, promo…) */
    ${END} [class*="rounded"] { border-radius: 0 !important; }
    ${END} [class*="bg-gray-"], ${END} [class*="bg-slate-"], ${END} [class*="bg-zinc-"] {
      background-color: rgba(28, 11, 11, .8) !important;
    }
    ${END} [class*="border-gray-"], ${END} [class*="border-slate-"], ${END} [class*="border-zinc-"],
    ${END} [class*="border-white"] { border-color: #3a1616 !important; }
    ${END} .bg-black\\/30 { background-color: rgba(28, 11, 11, .7) !important; }
    /* Store price buttons: premium (blue) in logo red; the gold-currency one keeps its gold */
    ${END} button.bg-blue-500\\/20 {
      background-color: rgba(249, 60, 60, .14) !important;
      border-color: #F93C3C !important;
      color: #F87171 !important;
    }
    ${END} button.bg-blue-500\\/20:hover { background-color: rgba(249, 60, 60, .26) !important; }

    /* Buttons: Exit (quiet) dark, Spectate / Keep playing / Requeue / Share (main) red */
    ${END} .win-action {
      border-radius: 0 !important;
      border: 2px solid #3a1616 !important;
      background: #1c0b0b !important;
      color: #f3e9e9 !important;
      box-shadow: none !important;
      transition: background .15s, border-color .15s, filter .15s !important;
    }
    ${END} .win-action:hover { border-color: #E66161 !important; filter: brightness(1.12); }
    ${END} .win-action-main {
      background: #F93C3C !important;
      border-color: #F93C3C !important;
      color: #fff !important;
      box-shadow: inset 0 -3px 0 #C32E2E !important;
    }
    ${END} .win-action-main:hover { background: #C32E2E !important; border-color: #C32E2E !important; }

    /* ================= Player info window & emoji window (centered pop-ups) ================= */
    ${WINDOWS} {
      background: rgba(18, 7, 7, .94) !important;
      border: 2px solid #3a1616 !important;
      border-top: 3px solid #F93C3C !important;
      border-radius: 0 !important;
      box-shadow: 0 20px 50px rgba(0, 0, 0, .6), 0 0 30px rgba(249, 60, 60, .16) !important;
      color: #f3e9e9 !important;
      scrollbar-color: #3a1616 transparent;
    }
    ${PP_CARD}::before { ${HEADER} }
    ${EMOJI_CARD}::before {
      ${HEADER}
      position: sticky;
      top: -.75rem;
      z-index: 2;
      flex-shrink: 0;
      margin: -.75rem -.75rem 0;
    }
    player-panel .backdrop-blur-\\[2px\\] { border-radius: 0 !important; background: none !important; }
    ${WINDOWS} [class*="rounded"] { border-radius: 0 !important; }
    ${WINDOWS} .bg-zinc-700\\/80 { background: #3a1616 !important; } /* dividers */
    ${WINDOWS} .bg-white\\/4, ${WINDOWS} .bg-zinc-800\\/70 { background: #1c0b0b !important; }
    ${WINDOWS} [class*="border-white"], ${WINDOWS} [class*="ring-zinc"], ${WINDOWS} [class*="border-zinc"] {
      border-color: #3a1616 !important;
      --tw-ring-color: #3a1616 !important;
    }
    ${WINDOWS} .text-zinc-400, ${WINDOWS} .text-zinc-500 { color: #a88484 !important; }

    /* Player name in the pixel font */
    ${PP_CARD} .mb-1 > .flex.items-center .flex-1 {
      font-family: "OFC Pixel", monospace !important;
      font-size: 12px !important;
      line-height: 1.5 !important;
      letter-spacing: .04em;
    }

    /* Action buttons (chat, emojis, target, trade, alliance…) */
    ${PP_CARD} button.group {
      background: #1c0b0b !important;
      border: 2px solid #3a1616 !important;
      transition: border-color .15s, background .15s, filter .15s !important;
    }
    ${PP_CARD} button.group:hover { border-color: #F93C3C !important; background: rgba(249, 60, 60, .12) !important; }

    /* Section titles of the emoji window in the pixel font */
    ${EMOJI_CARD} h3 {
      font-family: "OFC Pixel", monospace !important;
      font-size: 9px !important;
      font-weight: normal !important;
      letter-spacing: .1em !important;
      color: #E66161 !important;
    }
    ${EMOJI_CARD} button:hover { background: rgba(249, 60, 60, .16) !important; }
    ${EMOJI_CARD} button:active { background: rgba(249, 60, 60, .3) !important; }
    ${EMOJI_CARD} .border-dashed { border-color: #3a1616 !important; }
    ${EMOJI_CARD} .border-dashed:hover { border-color: #F93C3C !important; }

    /* Close buttons: square, red on hover */
    player-panel button.bg-zinc-700, emoji-table button.bg-zinc-700 {
      border-radius: 0 !important;
      background: #1c0b0b !important;
      border: 2px solid #F93C3C !important;
      color: #F93C3C !important;
    }
    player-panel button.bg-zinc-700:hover, emoji-table button.bg-zinc-700:hover {
      background: #F93C3C !important;
      color: #fff !important;
    }

    /* ================= Animated pixel coin instead of the game's gold icon ================= */
    /* Drawn a bit bigger than the game's icon (the GIF has empty margins);
       scale() doesn't change the layout, so nothing around it moves */
    img.ofc-gold { image-rendering: pixelated; object-fit: contain; transform: scale(${GOLD_SCALE}); }
  `;

  function ensureStyle() {
    if (document.getElementById("ofc-hud-style")) return;
    const style = document.createElement("style");
    style.id = "ofc-hud-style";
    style.textContent = CSS;
    (document.head || document.documentElement).append(style);
  }

  // The style is pure CSS (the bottom panel is matched with :has()), so it
  // applies from the very first frame of a match. Re-add it if a page change
  // ever removes it.
  ensureStyle();
  setInterval(ensureStyle, 2000);

  // Victory sound, played when the victory screen appears.
  // The win itself is detected by win-detect.js (page world): this isolated
  // script can't read the game's variables, so it waits for its signal.
  const VICTORY_SOUND_URL = chrome.runtime.getURL("sounds/victory.mp3");
  const VICTORY_VOLUME = 0.6;

  window.addEventListener("ofc-victory", () => {
    const audio = new Audio(VICTORY_SOUND_URL);
    audio.volume = VICTORY_VOLUME;
    audio.play().catch(() => {}); // autoplay blocked: stay silent
  });

  // ---------- Game's gold icon -> animated pixel coin, everywhere it appears ----------
  const GOLD_URL = chrome.runtime.getURL("icons/gold-coin.webp");

  function swapGoldIcons() {
    for (const img of document.querySelectorAll('img[src*="GoldCoinIcon"]')) {
      img.src = GOLD_URL;
      img.classList.add("ofc-gold");
    }
  }

  let swapQueued = false;
  new MutationObserver(() => {
    if (swapQueued) return;
    swapQueued = true;
    requestAnimationFrame(() => {
      swapQueued = false;
      swapGoldIcons();
    });
  }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["src"] });
  setInterval(swapGoldIcons, 1000); // safety net if frames are paused
  swapGoldIcons();
})();
