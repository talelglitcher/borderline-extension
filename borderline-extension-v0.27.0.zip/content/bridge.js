// Extension "isolated" world: has access to chrome.storage.
// - Passes module settings to the page scripts (troop-color.js, highlight.js,
//   hide-skins.js, troop-alerts.js, ping.js…) through data attributes on <html>.
// - Handles the Structure Highlight keybind.

const root = document.documentElement;

const STRUCTURE_TYPES = ["City", "Port", "Factory", "Defense Post", "SAM Launcher", "Missile Silo"];
const DEFAULTS = {
  troopColors: false,
  highlight: false,
  highlightTypes: STRUCTURE_TYPES,
  hideSkins: false,
  keepOwnSkin: true,
  highlightKey: null,
  troopAlerts: false,
  traitors: false,
  pings: false,
  pingKey: null,
  portSpots: false,
};

// Ping marker image, for the page script that draws pings
root.dataset.ofcPingGif = chrome.runtime.getURL("icons/ping.gif");

const settings = { ...DEFAULTS };

function apply(changed) {
  Object.assign(settings, changed);
  if ("hideSkins" in changed) root.dataset.ofcHideSkins = changed.hideSkins ? "on" : "off";
  if ("keepOwnSkin" in changed) root.dataset.ofcKeepOwnSkin = changed.keepOwnSkin ? "on" : "off";
  if ("troopColors" in changed) root.dataset.ofcTroopColors = changed.troopColors ? "on" : "off";
  if ("troopAlerts" in changed) root.dataset.ofcTroopAlerts = changed.troopAlerts ? "on" : "off";
  if ("traitors" in changed) root.dataset.ofcTraitors = changed.traitors ? "on" : "off";
  if ("pings" in changed) root.dataset.ofcPings = changed.pings ? "on" : "off";
  if ("portSpots" in changed) root.dataset.ofcPortSpots = changed.portSpots ? "on" : "off";
  if ("pingKey" in changed) root.dataset.ofcPingKey = changed.pingKey?.code || "";
  if ("highlight" in changed) root.dataset.ofcHighlight = changed.highlight ? "on" : "off";
  if ("highlightTypes" in changed) root.dataset.ofcHighlightTypes = (changed.highlightTypes || []).join("|");
}

chrome.storage.sync.get(DEFAULTS, apply);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "sync") return;
  const updated = {};
  for (const [key, { newValue }] of Object.entries(changes)) updated[key] = newValue;
  apply(updated);
});

// ---------- Structure Highlight keybind ----------
function isTyping(target) {
  const el = target?.closest?.("input, textarea, select, [contenteditable=''], [contenteditable='true']");
  return !!el;
}

window.addEventListener(
  "keydown",
  (e) => {
    const key = settings.highlightKey;
    if (!key || e.code !== key.code || e.repeat) return;
    if (e.ctrlKey || e.altKey || e.metaKey) return;
    // Don't trigger while typing in chat, username fields, etc.
    if (isTyping(e.composedPath()[0])) return;
    // The key is ours: keep the game from also reacting to it
    e.preventDefault();
    e.stopImmediatePropagation();
    const on = !settings.highlight;
    chrome.storage.sync.set({ highlight: on });
    showToast(`STRUCTURE HIGHLIGHT ${on ? "ON" : "OFF"}`, on);
  },
  true
);

// Small confirmation shown at the top of the screen
let toast = null;
let toastTimer = null;
function showToast(text, on) {
  if (!toast) {
    toast = document.createElement("div");
    // "popover" puts the toast in the browser's top layer, above the game's own
    // dialogs and menus (a high z-index isn't enough for those).
    toast.popover = "manual";
    toast.style.cssText = [
      "position:fixed",
      "inset:56px auto auto 50%",
      "margin:0",
      "transform:translateX(-50%)",
      "z-index:2147483647",
      "padding:8px 14px",
      "background:#120707",
      "border:2px solid #3a1616",
      "font:bold 12px/1 ui-monospace, Consolas, monospace",
      "letter-spacing:.08em",
      "pointer-events:none",
      "transition:opacity .25s",
    ].join(";");
    document.documentElement.append(toast);
  }
  toast.textContent = text;
  toast.style.color = on ? "#4ADE80" : "#F87171";
  toast.style.borderColor = on ? "#4ADE80" : "#F87171";
  toast.style.opacity = "1";
  try {
    if (toast.matches(":popover-open")) toast.hidePopover();
    toast.showPopover(); // re-show so it stays on top of anything opened since
  } catch {}
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (toast.style.opacity = "0"), 1200);
}
