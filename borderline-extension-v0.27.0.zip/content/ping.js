// Runs in the openfront.io page context ("MAIN" world).
//
// Map Ping module: press the ping key to drop a ping on the map where the
// mouse is. Other Borderline users in the same match see it too (sent through
// the ping relay by ping-net.js, which has the network access).
// A ping stays on its map spot (it follows the camera), shows who sent it,
// and fades after a few seconds. Pings outside the view are shown at the edge
// of the screen, smaller.

(() => {
  const root = document.documentElement;
  const isEnabled = () => root.dataset.ofcPings === "on";
  const pingKey = () => root.dataset.ofcPingKey || "";
  const gifUrl = () => root.dataset.ofcPingGif || "";

  const PING_MS = 4500;
  const FADE_MS = 500;
  const SIZE = 56; // px
  const ANCHOR_Y = 0.82; // the ring's center in the GIF (fraction of its height)
  const COOLDOWN_MS = 800;
  const MAX_PINGS = 12;
  const EDGE = 28; // margin for pings outside the view

  // ---------- Messages with ping-net.js (isolated world) ----------
  const post = (msg) => window.postMessage({ source: "ofc-ping-main", ...msg }, location.origin);

  // ---------- Game access ----------
  function gameContext() {
    const el = document.querySelector("player-info-overlay");
    const game = el?.game;
    const transform = el?.transform;
    if (!game || !transform?.worldToScreenCoordinates || typeof game.gameID !== "function") return null;
    return { game, transform };
  }
  // In a match: the bottom control panel is shown, or the match is in its
  // spawn phase (choosing a starting location, before the panel appears)
  function inMatch(gc) {
    if (document.querySelector("control-panel > div.w-full")) return true;
    try {
      return !!gc?.game.inSpawnPhase?.() && !gc.game.gameOver?.();
    } catch {
      return false;
    }
  }

  // Your in-game name, also before you've spawned
  function myName(game) {
    try {
      const me = game.myPlayer?.() ?? game.playerByClientID?.(game.myClientID?.());
      return me?.displayName?.() || "";
    } catch {
      return "";
    }
  }

  // Tell ping-net.js which match we're in (it joins that match's room)
  let room = null;
  setInterval(() => {
    let id = null;
    try {
      const gc = gameContext();
      if (isEnabled() && gc && inMatch(gc)) id = String(gc.game.gameID());
    } catch {}
    if (id !== room) {
      room = id;
      post({ type: "room", room });
      if (!room) clearPings();
    }
  }, 1000);

  // ---------- Placing a ping ----------
  let mouseX = innerWidth / 2;
  let mouseY = innerHeight / 2;
  window.addEventListener(
    "pointermove",
    (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    },
    { capture: true, passive: true }
  );

  function isTyping(target) {
    return !!target?.closest?.("input, textarea, select, [contenteditable=''], [contenteditable='true']");
  }

  let lastSent = 0;
  window.addEventListener(
    "keydown",
    (e) => {
      const code = pingKey();
      if (!code || e.code !== code || e.repeat || !isEnabled()) return;
      if (e.ctrlKey || e.altKey || e.metaKey) return;
      if (isTyping(e.composedPath()[0])) return;
      const gc = gameContext();
      if (!gc || !inMatch(gc)) return;
      // The key is ours: keep the game from also reacting to it
      e.preventDefault();
      e.stopImmediatePropagation();

      const now = performance.now();
      if (now - lastSent < COOLDOWN_MS) return;
      const w = gc.transform.screenToWorldCoordinates(mouseX, mouseY);
      const x = Math.round(w.x);
      const y = Math.round(w.y);
      if (!gc.game.isValidCoord(x, y)) return;
      lastSent = now;

      const name = myName(gc.game);
      addPing(x, y, "YOU", true);
      post({ type: "out", x, y, n: name });
    },
    true
  );

  // Pings from other players
  window.addEventListener("message", (e) => {
    // Checked by origin and tag (Firefox wraps "window" differently for extension scripts)
    if (e.origin !== location.origin || e.data?.source !== "ofc-ping-net" || e.data.type !== "in") return;
    if (!isEnabled() || !room) return;
    const gc = gameContext();
    const x = Math.round(Number(e.data.x));
    const y = Math.round(Number(e.data.y));
    if (!gc || !Number.isFinite(x) || !Number.isFinite(y) || !gc.game.isValidCoord(x, y)) return;
    addPing(x, y, typeof e.data.n === "string" ? e.data.n.slice(0, 40) : "", false);
  });

  // ---------- Drawing ----------
  // Layer right above the map (and our other map overlays), below the game's UI
  const layer = document.createElement("div");
  layer.id = "ofc-pings";
  layer.style.cssText = "position:fixed;inset:0;pointer-events:none;overflow:hidden";

  function placeLayer() {
    const mapCanvas =
      document.getElementById("webgl-debug-canvas") ||
      [...document.querySelectorAll("canvas")].find((c) => !c.id.startsWith("ofc-"));
    if (!mapCanvas) return false;
    let anchor = mapCanvas;
    while (anchor.nextElementSibling?.id?.startsWith("ofc-") && anchor.nextElementSibling !== layer) {
      anchor = anchor.nextElementSibling;
    }
    if (layer.previousElementSibling !== anchor) anchor.after(layer);
    return true;
  }

  const pings = [];
  let running = false;

  function addPing(x, y, name, mine) {
    if (!placeLayer()) return;
    const el = document.createElement("div");
    el.style.cssText = `position:absolute;left:0;top:0;width:${SIZE}px;height:${SIZE}px;will-change:transform`;

    const img = document.createElement("img");
    img.src = gifUrl();
    img.alt = "";
    img.style.cssText = `width:${SIZE}px;height:${SIZE}px;image-rendering:pixelated;display:block;` +
      "filter:drop-shadow(0 2px 0 rgba(18,7,7,.6))";

    const label = document.createElement("div");
    label.textContent = name;
    label.style.cssText = [
      "position:absolute",
      "left:50%",
      "bottom:100%",
      "transform:translateX(-50%)",
      "margin-bottom:2px",
      "padding:3px 5px 2px",
      "white-space:nowrap",
      "font:8px/1 'OFC Pixel', ui-monospace, monospace",
      "letter-spacing:.04em",
      `color:${mine ? "#4ADE80" : "#F3E9E9"}`,
      "background:rgba(18,7,7,.85)",
      `border:1px solid ${mine ? "#4ADE80" : "#F93C3C"}`,
    ].join(";");
    if (!name) label.hidden = true;

    el.append(label, img);
    layer.append(el);
    el.animate(
      [
        { opacity: 0, scale: "0.4" },
        { opacity: 1, scale: "1.12", offset: 0.7 },
        { opacity: 1, scale: "1" },
      ],
      { duration: 260, easing: "ease-out" }
    );

    pings.push({ x, y, el, start: performance.now() });
    while (pings.length > MAX_PINGS) pings.shift().el.remove();
    playSound(mine);
    if (!running) {
      running = true;
      requestAnimationFrame(frame);
    }
  }

  function clearPings() {
    for (const p of pings) p.el.remove();
    pings.length = 0;
  }

  function frame() {
    const gc = gameContext();
    const now = performance.now();
    if (gc) {
      const t = gc.transform;
      const origin = t.worldToScreenCoordinates({ x: 0, y: 0 });
      const s = t.scale || 1;
      for (let i = pings.length - 1; i >= 0; i--) {
        const p = pings[i];
        const age = now - p.start;
        if (age > PING_MS) {
          p.el.remove();
          pings.splice(i, 1);
          continue;
        }
        // Tile center on screen
        let sx = origin.x + (p.x + 0.5) * s;
        let sy = origin.y + (p.y + 0.5) * s;
        const outside = sx < EDGE || sy < EDGE || sx > innerWidth - EDGE || sy > innerHeight - EDGE;
        if (outside) {
          sx = Math.min(innerWidth - EDGE, Math.max(EDGE, sx));
          sy = Math.min(innerHeight - EDGE, Math.max(EDGE, sy));
        }
        const scale = outside ? 0.6 : 1;
        p.el.style.transform =
          `translate(${Math.round(sx - SIZE / 2)}px, ${Math.round(sy - SIZE * ANCHOR_Y)}px) scale(${scale})`;
        p.el.style.transformOrigin = `50% ${ANCHOR_Y * 100}%`;
        p.el.style.opacity = String((outside ? 0.75 : 1) * Math.min(1, (PING_MS - age) / FADE_MS));
      }
    } else {
      clearPings();
    }
    if (pings.length) requestAnimationFrame(frame);
    else running = false;
  }

  // ---------- Sound: a short, quiet two-note blip ----------
  let audio = null;
  function playSound(mine) {
    try {
      audio ??= new AudioContext();
      if (audio.state === "suspended") audio.resume();
      const t0 = audio.currentTime;
      const notes = mine ? [880, 1320] : [1320, 990];
      notes.forEach((f, i) => {
        const osc = audio.createOscillator();
        const gain = audio.createGain();
        osc.type = "sine";
        osc.frequency.value = f;
        const t = t0 + i * 0.08;
        gain.gain.setValueAtTime(0.0001, t);
        gain.gain.exponentialRampToValueAtTime(0.06, t + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
        osc.connect(gain).connect(audio.destination);
        osc.start(t);
        osc.stop(t + 0.2);
      });
    } catch {}
  }
})();
