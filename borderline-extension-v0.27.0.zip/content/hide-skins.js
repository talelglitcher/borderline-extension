// Runs in the openfront.io page context ("MAIN" world).
//
// Hide Skins module: other players' cosmetics (territory skins / patterns,
// colors, flags, crowns, effects) are shown as the default look.
// Sub-option "keep my skin": your own cosmetics stay visible.
//
// The game already has this filter in its graphics settings
// ("cosmetics.showFrom": everyone / teammates / self / none). We override that
// value while the module is on, WITHOUT changing your saved game settings:
// - reads of the settings return the overridden value;
// - writes (when you change other graphics settings in the game) keep your
//   real "showFrom" value.

(() => {
  const root = document.documentElement;
  const KEY = "settings.graphics";
  const CHANGE_EVENT = `event:user-settings-changed:${KEY}`;

  // null = don't override; otherwise the showFrom value to force
  function forcedShowFrom() {
    if (root.dataset.ofcHideSkins !== "on") return null;
    return root.dataset.ofcKeepOwnSkin === "on" ? "self" : "none";
  }

  const proto = Storage.prototype;
  const origGetItem = proto.getItem;
  const origSetItem = proto.setItem;

  // The user's real showFrom value, as saved by the game (may be undefined)
  let realShowFrom;

  function parse(raw) {
    try {
      const v = JSON.parse(raw);
      return v && typeof v === "object" ? v : {};
    } catch {
      return {};
    }
  }

  function withShowFrom(raw, showFrom) {
    const v = parse(raw);
    const cosmetics = { ...(v.cosmetics || {}) };
    if (showFrom === undefined) delete cosmetics.showFrom;
    else cosmetics.showFrom = showFrom;
    return JSON.stringify({ ...v, cosmetics });
  }

  proto.getItem = function (key) {
    const raw = origGetItem.call(this, key);
    if (this !== localStorage || key !== KEY) return raw;
    realShowFrom = parse(raw).cosmetics?.showFrom;
    const forced = forcedShowFrom();
    return forced ? withShowFrom(raw, forced) : raw;
  };

  proto.setItem = function (key, value) {
    if (this === localStorage && key === KEY && forcedShowFrom()) {
      // Don't save our override: put back the user's real value
      value = withShowFrom(value, realShowFrom);
    }
    return origSetItem.call(this, key, value);
  };

  // ---------- Live switch ----------
  // The game caches settings in memory: update its cache, then send the game's
  // own "settings changed" event so it re-applies cosmetics right away.
  // Game components that hold the settings object (cheap lookup, no full-page scan)
  const SETTINGS_HOLDERS = "player-info-overlay, control-panel, game-left-sidebar, game-right-sidebar, events-display";

  let settingsClass = null;
  function findSettingsClass() {
    if (settingsClass) return settingsClass;
    for (const el of document.querySelectorAll(SETTINGS_HOLDERS)) {
      const cls = el.userSettings?.constructor;
      if (cls?.cache instanceof Map) return (settingsClass = cls);
    }
    return null;
  }

  // Make sure the game sees the right "showFrom" value.
  // Runs on every switch change, and regularly in case the game cached the
  // settings before the extension's options were loaded.
  //
  // IMPORTANT: the game's "settings changed" event makes it rebuild the whole
  // map terrain (it takes seconds). So we only compare the one value we care
  // about, and only send the event when it really has to change.
  function apply() {
    const cls = findSettingsClass();
    if (!cls || !cls.cache.has(KEY)) return; // not cached yet: next read uses our value

    const cached = cls.cache.get(KEY);
    const real = parse(origGetItem.call(localStorage, KEY)).cosmetics?.showFrom;
    const wanted = forcedShowFrom() ?? real;
    if (parse(cached).cosmetics?.showFrom === wanted) return; // already right: don't touch the game

    // Change only showFrom, keep everything else exactly as the game has it
    const next = withShowFrom(cached, wanted);
    cls.cache.set(KEY, next);
    window.dispatchEvent(new CustomEvent(CHANGE_EVENT, { detail: next }));
  }

  new MutationObserver(apply).observe(root, {
    attributes: true,
    attributeFilter: ["data-ofc-hide-skins", "data-ofc-keep-own-skin"],
  });
  setInterval(apply, 1000);
})();
