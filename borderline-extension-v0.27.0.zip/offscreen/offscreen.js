// Hidden extension page that plays the popup sounds.
//
// Sounds are synthesized (no audio files), in the style of a clean interface
// rather than a game: short filtered noise "taps" and soft low tones, very
// quiet, no melodies or bleeps.

const ctx = new AudioContext();
const MASTER = 0.5; // overall volume

const master = ctx.createGain();
master.gain.value = MASTER;
master.connect(ctx.destination);

// Short white-noise buffer, reused for every tap / whoosh
const noise = (() => {
  const buffer = ctx.createBuffer(1, ctx.sampleRate * 0.6, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  return buffer;
})();

// Filtered noise burst: crisp mechanical click, or a soft "air" whoosh
function noiseBurst({ start = 0, duration = 0.03, freq = 3000, q = 1.2, gain = 0.2, sweepTo = null, type = "bandpass" }) {
  const t0 = ctx.currentTime + start;
  const src = ctx.createBufferSource();
  src.buffer = noise;
  const filter = ctx.createBiquadFilter();
  filter.type = type;
  filter.Q.value = q;
  filter.frequency.setValueAtTime(freq, t0);
  if (sweepTo) filter.frequency.exponentialRampToValueAtTime(sweepTo, t0 + duration);
  const amp = ctx.createGain();
  amp.gain.setValueAtTime(0.0001, t0);
  amp.gain.exponentialRampToValueAtTime(gain, t0 + Math.min(0.012, duration / 3));
  amp.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
  src.connect(filter).connect(amp).connect(master);
  src.start(t0);
  src.stop(t0 + duration + 0.02);
}

// Soft low sine "body" under a sound
function thump({ start = 0, duration = 0.12, from = 140, to = 90, gain = 0.12 }) {
  const t0 = ctx.currentTime + start;
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(from, t0);
  osc.frequency.exponentialRampToValueAtTime(to, t0 + duration);
  const amp = ctx.createGain();
  amp.gain.setValueAtTime(0.0001, t0);
  amp.gain.exponentialRampToValueAtTime(gain, t0 + 0.01);
  amp.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
  osc.connect(amp).connect(master);
  osc.start(t0);
  osc.stop(t0 + duration + 0.02);
}

// Popup open sound: an audio file, decoded once and kept in memory
const OPEN_VOLUME = 0.15;
const openBuffer = fetch(chrome.runtime.getURL("sounds/open.wav"))
  .then((r) => r.arrayBuffer())
  .then((data) => ctx.decodeAudioData(data))
  .catch(() => null);

async function playFile(bufferPromise, volume) {
  const buffer = await bufferPromise;
  if (!buffer) return;
  const src = ctx.createBufferSource();
  src.buffer = buffer;
  const amp = ctx.createGain();
  amp.gain.value = volume;
  src.connect(amp).connect(master);
  src.start();
}

const SOUNDS = {
  // Popup opens: the open.wav sound
  open() {
    playFile(openBuffer, OPEN_VOLUME);
  },
  // Switch on: a crisp double click (like a physical switch), slightly brighter
  on() {
    noiseBurst({ duration: 0.018, freq: 4200, q: 2, gain: 0.22 });
    noiseBurst({ start: 0.035, duration: 0.02, freq: 5200, q: 2, gain: 0.14 });
    thump({ duration: 0.05, from: 220, to: 180, gain: 0.05 });
  },
  // Switch off: a single, duller click
  off() {
    noiseBurst({ duration: 0.022, freq: 2600, q: 2, gain: 0.2 });
    thump({ duration: 0.05, from: 170, to: 130, gain: 0.05 });
  },
  // Any other button: a tiny, quiet tick
  click() {
    noiseBurst({ duration: 0.014, freq: 5500, q: 2.5, gain: 0.12 });
  },
};

function playSound(name) {
  if (ctx.state === "suspended") ctx.resume();
  SOUNDS[name]?.();
}

// Firefox: this file runs inside the background page itself (no offscreen
// documents there), and background.js calls it directly.
globalThis.playBorderlineSound = playSound;

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.target === "offscreen") playSound(msg.sound);
});
