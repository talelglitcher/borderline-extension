// Background service worker (Chrome) / background page (Firefox).
//
// Popup sounds: the popup is closed instantly by Chrome, so a sound played
// from the popup itself would be cut off. Sounds are played from a hidden
// "offscreen" extension page instead:
// the popup sends { sound: "..." } messages for opening and buttons.
// (No sound when the popup closes.)

// Update check (see update.js): when Chrome starts and when the extension is
// installed or reloaded
if (typeof importScripts === "function") importScripts("update.js");
async function checkForUpdate() {
  if (typeof BORDERLINE_UPDATE === "undefined") return;
  BORDERLINE_UPDATE.updateBadge(await BORDERLINE_UPDATE.check());
}
chrome.runtime.onStartup.addListener(checkForUpdate);
chrome.runtime.onInstalled.addListener(checkForUpdate);

const OFFSCREEN_URL = "offscreen/offscreen.html";
let creating = null;

async function ensureOffscreen() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)],
  });
  if (contexts.length) return;
  creating ??= chrome.offscreen
    .createDocument({
      url: OFFSCREEN_URL,
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Short interface sounds for the extension popup",
    })
    .finally(() => (creating = null));
  await creating;
}

async function play(sound) {
  // Firefox has no offscreen documents, but its background page can play
  // audio itself: the sound code (offscreen.js) is loaded right here.
  if (!chrome.offscreen) {
    globalThis.playBorderlineSound?.(sound);
    return;
  }
  await ensureOffscreen();
  chrome.runtime.sendMessage({ target: "offscreen", sound }).catch(() => {});
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.target === "background" && msg.sound) play(msg.sound);
});
