const STRUCTURE_TYPES = [
  { id: "City", label: "City" },
  { id: "Port", label: "Port" },
  { id: "Factory", label: "Factory" },
  { id: "Defense Post", label: "Defense" },
  { id: "SAM Launcher", label: "SAM" },
  { id: "Missile Silo", label: "Silo" },
];

const DEFAULTS = {
  troopColors: false,
  highlight: false,
  highlightTypes: STRUCTURE_TYPES.map((t) => t.id),
  hideSkins: false,
  keepOwnSkin: true,
  highlightKey: null, // { code, label } — key that toggles Structure Highlight in game
  troopAlerts: false,
  traitors: false,
  pings: false,
  pingKey: null, // { code, label } — key that drops a ping in game
  pingServer: "", // address of the ping relay
  portSpots: false,
};

// ---------- Sounds ----------
// Played by the background script (a sound played here would be cut off when
// the popup closes).
function sound(name) {
  try {
    chrome.runtime.sendMessage({ target: "background", sound: name })?.catch?.(() => {});
  } catch {}
}
sound("open");

// Switches: on/off bleep. Every other button or checkbox: short tick.
document.addEventListener("change", (e) => {
  const el = e.target;
  if (el.classList.contains("switch")) sound(el.checked ? "on" : "off");
  else if (el.type === "checkbox") sound("click");
});
document.addEventListener("click", (e) => {
  if (e.target.closest("button")) sound("click");
});

// Simple on/off settings: storage key -> checkbox
const toggles = {
  troopColors: document.getElementById("opt-troopColors"),
  troopAlerts: document.getElementById("opt-troopAlerts"),
  traitors: document.getElementById("opt-traitors"),
  pings: document.getElementById("opt-pings"),
  portSpots: document.getElementById("opt-portSpots"),
  highlight: document.getElementById("opt-highlight"),
  hideSkins: document.getElementById("opt-hideSkins"),
  keepOwnSkin: document.getElementById("opt-keepOwnSkin"),
};

// Module switch -> its submenu (opened automatically when the module is turned on)
const submenuOf = {
  highlight: "highlight-menu",
  hideSkins: "skins-menu",
  pings: "ping-menu",
};

// ---------- Submenus ----------
function setMenuOpen(menuId, open) {
  document.getElementById(menuId).classList.toggle("open", open);
  document.querySelector(`.expand[aria-controls="${menuId}"]`).setAttribute("aria-expanded", String(open));
}
document.querySelectorAll(".expand").forEach((btn) => {
  btn.addEventListener("click", () => {
    const id = btn.getAttribute("aria-controls");
    setMenuOpen(id, !document.getElementById(id).classList.contains("open"));
  });
});

// ---------- Structure Highlight: structure choices ----------
const typeList = document.getElementById("highlight-types");
const typeBoxes = STRUCTURE_TYPES.map(({ id, label }) => {
  const row = document.createElement("label");
  row.className = "choice";
  const box = document.createElement("input");
  box.type = "checkbox";
  box.value = id;
  row.append(box, label);
  typeList.append(row);
  return box;
});

function saveTypes() {
  chrome.storage.sync.set({ highlightTypes: typeBoxes.filter((b) => b.checked).map((b) => b.value) });
}
typeBoxes.forEach((box) => box.addEventListener("change", saveTypes));

document.querySelectorAll(".quick button").forEach((btn) => {
  btn.addEventListener("click", () => {
    const all = btn.dataset.select === "all";
    typeBoxes.forEach((b) => (b.checked = all));
    saveTypes();
  });
});

// ---------- Keybinds (Structure Highlight, Map Ping) ----------
const MODIFIERS = new Set(["Shift", "Control", "Alt", "Meta", "AltGraph", "CapsLock"]);

function keyLabel(e) {
  if (e.key === " ") return "SPACE";
  if (e.key.length === 1) return e.key.toUpperCase();
  return e.key.replace(/^Arrow/, "").toUpperCase(); // F1, TAB, UP, ENTER…
}

// A button that records one key into a storage setting
function keybindPicker(button, storageKey) {
  let current = null;
  let listening = false;

  const show = () => {
    button.classList.toggle("listening", listening);
    button.textContent = listening ? "PRESS A KEY" : current ? current.label : "NONE";
  };
  const stop = () => {
    listening = false;
    show();
  };

  button.addEventListener("click", () => {
    listening = !listening;
    show();
  });
  button.addEventListener("blur", stop);

  document.addEventListener(
    "keydown",
    (e) => {
      if (!listening || MODIFIERS.has(e.key)) return;
      e.preventDefault();
      e.stopPropagation();
      if (e.key === "Escape") return stop(); // cancel
      current = e.key === "Backspace" || e.key === "Delete" ? null : { code: e.code, label: keyLabel(e) };
      chrome.storage.sync.set({ [storageKey]: current });
      stop();
    },
    true
  );

  return {
    set(value) {
      current = value;
      show();
    },
  };
}

const highlightKeyPicker = keybindPicker(document.getElementById("highlight-key"), "highlightKey");
const pingKeyPicker = keybindPicker(document.getElementById("ping-key"), "pingKey");

// ---------- Map Ping: relay address ----------
const pingServer = document.getElementById("ping-server");
pingServer.addEventListener("change", () => {
  chrome.storage.sync.set({ pingServer: pingServer.value.trim() });
});

// ---------- Load saved settings ----------
chrome.storage.sync.get(DEFAULTS, (saved) => {
  for (const [key, input] of Object.entries(toggles)) {
    input.checked = saved[key];
    input.addEventListener("change", () => {
      chrome.storage.sync.set({ [key]: input.checked });
      if (submenuOf[key] && input.checked) setMenuOpen(submenuOf[key], true);
    });
  }
  const selected = new Set(saved.highlightTypes);
  typeBoxes.forEach((b) => (b.checked = selected.has(b.value)));
  highlightKeyPicker.set(saved.highlightKey);
  pingKeyPicker.set(saved.pingKey);
  pingServer.value = saved.pingServer || "";
});

// Keep the switch in sync when the highlight is toggled with the keybind in game
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync" && "highlight" in changes) toggles.highlight.checked = changes.highlight.newValue;
});

document.getElementById("open-game").addEventListener("click", () => {
  chrome.tabs.create({ url: "https://openfront.io/" });
});

// ---------- Config: export / import ----------
const configStatus = document.getElementById("config-status");

document.getElementById("config-export").addEventListener("click", async () => {
  try {
    BORDERLINE_CONFIG.downloadConfig(await BORDERLINE_CONFIG.exportConfig());
    configStatus.textContent = "Saved to your downloads.";
  } catch (err) {
    configStatus.textContent = `Export failed: ${err.message}`;
  }
  configStatus.hidden = false;
});

// Import happens in its own page: a file picker can close this popup.
document.getElementById("config-import").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("popup/import.html") });
});

// ---------- Update ----------
// Checks the latest published version (see update.js). When it's newer:
// DOWNLOAD gets the zip, the user unzips it over the extension folder, then
// RELOAD restarts the extension from the new files.
(async () => {
  if (typeof BORDERLINE_UPDATE === "undefined") return;
  const info = await BORDERLINE_UPDATE.check();
  BORDERLINE_UPDATE.updateBadge(info);
  if (!info?.available) return;

  document.getElementById("update-version").textContent = `v${info.latest}`;
  document.getElementById("update").hidden = false;
  document.getElementById("update-download").addEventListener("click", () => {
    chrome.tabs.create({ url: info.url });
  });
  document.getElementById("update-reload").addEventListener("click", () => {
    chrome.runtime.reload();
  });
})();
