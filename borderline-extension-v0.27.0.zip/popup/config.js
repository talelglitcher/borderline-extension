// Shared by the popup (export) and the import page.
//
// Export / import of the extension's configuration: every setting saved in
// chrome.storage.sync, written to a small JSON file.
// Only known settings are imported, and each one is type-checked, so a broken
// or unrelated file can't put the extension in a bad state.

const BORDERLINE_CONFIG = (() => {
  const FORMAT = "borderline-config";
  const FORMAT_VERSION = 1;

  // Promise-based extension API: "browser" in Firefox, "chrome" in Chrome
  const api = globalThis.browser ?? chrome;

  const isBool = (v) => typeof v === "boolean";
  const STRUCTURES = ["City", "Port", "Factory", "Defense Post", "SAM Launcher", "Missile Silo"];

  // setting -> validator
  const SCHEMA = {
    troopColors: isBool,
    troopAlerts: isBool,
    traitors: isBool,
    pings: isBool,
    portSpots: isBool,
    pingKey: (v) => v === null || (v && typeof v.code === "string" && typeof v.label === "string"),
    pingServer: (v) => typeof v === "string" && v.length < 300,
    highlight: isBool,
    highlightTypes: (v) => Array.isArray(v) && v.every((t) => STRUCTURES.includes(t)),
    highlightKey: (v) => v === null || (v && typeof v.code === "string" && typeof v.label === "string"),
    hideSkins: isBool,
    keepOwnSkin: isBool,
    statsLink: (v) => v === null || (typeof v === "string" && v.length < 300),
    statsWindowPos: (v) => v === null || (v && Number.isFinite(v.x) && Number.isFinite(v.y)),
    statsCollapsed: isBool,
  };

  async function exportConfig() {
    const all = await api.storage.sync.get(null);
    const settings = {};
    for (const key of Object.keys(SCHEMA)) if (key in all) settings[key] = all[key];
    return {
      format: FORMAT,
      formatVersion: FORMAT_VERSION,
      extensionVersion: api.runtime.getManifest().version,
      exportedAt: new Date().toISOString(),
      settings,
    };
  }

  function downloadConfig(config) {
    const blob = new Blob([JSON.stringify(config, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `borderline-config-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  // Returns { applied: [...keys], skipped: [...keys] }; throws on an invalid file
  async function importConfig(text) {
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error("This file isn't valid JSON.");
    }
    if (!data || data.format !== FORMAT || typeof data.settings !== "object" || !data.settings) {
      throw new Error("This isn't a Borderline configuration file.");
    }
    const applied = [];
    const skipped = [];
    const values = {};
    for (const [key, value] of Object.entries(data.settings)) {
      if (SCHEMA[key] && SCHEMA[key](value)) {
        values[key] = value;
        applied.push(key);
      } else {
        skipped.push(key);
      }
    }
    if (!applied.length) throw new Error("No usable settings found in this file.");
    await api.storage.sync.set(values);
    return { applied, skipped };
  }

  return { exportConfig, downloadConfig, importConfig, SCHEMA };
})();
