// Import page: reads a borderline-config file (picked or dropped) and applies it.

const drop = document.getElementById("drop");
const fileInput = document.getElementById("file");
const result = document.getElementById("result");
const closeBtn = document.getElementById("close");

// Readable names for the result message
const NAMES = {
  troopColors: "Colored troops",
  troopAlerts: "Troop loss alerts",
  traitors: "Traitor highlight",
  pings: "Map ping",
  portSpots: "Port spots",
  pingKey: "Ping keybind",
  pingServer: "Ping server",
  highlight: "Structure highlight",
  highlightTypes: "Highlighted structures",
  highlightKey: "Highlight keybind",
  hideSkins: "Hide skins",
  keepOwnSkin: "Keep my skin",
  statsLink: "Ranked window link",
  statsWindowPos: "Ranked window position",
  statsCollapsed: "Ranked window minimized",
};

function show(kind, html) {
  result.className = `result ${kind}`;
  result.innerHTML = html;
  result.hidden = false;
}

async function handle(file) {
  if (!file) return;
  try {
    const { applied, skipped } = await BORDERLINE_CONFIG.importConfig(await file.text());
    const list = applied.map((k) => NAMES[k] || k).join(", ");
    show(
      "ok",
      `<strong>Configuration imported.</strong> ${applied.length} setting(s) applied: ${list}.` +
        (skipped.length ? `<br>${skipped.length} unknown or invalid entry(ies) ignored.` : "") +
        `<br>Reload the OpenFront page (F5) to apply everything in game.`
    );
    closeBtn.hidden = false;
  } catch (err) {
    show("error", `<strong>Import failed.</strong> ${err.message}`);
  }
}

fileInput.addEventListener("change", () => handle(fileInput.files[0]));

drop.addEventListener("dragover", (e) => {
  e.preventDefault();
  drop.classList.add("over");
});
drop.addEventListener("dragleave", () => drop.classList.remove("over"));
drop.addEventListener("drop", (e) => {
  e.preventDefault();
  drop.classList.remove("over");
  handle(e.dataTransfer.files[0]);
});

closeBtn.addEventListener("click", () => window.close());
